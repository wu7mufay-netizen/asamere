@echo off
echo ===================================
echo Asamere Furniture MySQL Setup Script
echo ===================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
  echo ERROR: Node.js is not installed or not in your PATH.
  echo Please install Node.js from https://nodejs.org/
  goto :EOF
)

echo Node.js is installed.
echo.

REM Create server directory if it doesn't exist
if not exist server mkdir server

echo Installing server dependencies...
cd server
call npm install

echo.
echo Database setup script is ready to run.
echo.
echo Before continuing, make sure:
echo 1. MySQL Server is installed and running
echo 2. You have updated the database connection settings in:
echo    - server/server.js
echo    - server/db-setup.js
echo.
echo Press any key to continue with database setup...
pause >nul

echo Running database setup script...
call npm run setup

if %ERRORLEVEL% neq 0 (
  echo.
  echo ERROR: Database setup failed.
  echo Please check your MySQL connection settings and try again.
  goto :EOF
)

echo.
echo Database setup completed successfully!
echo.
echo Starting the server...
echo (Press Ctrl+C to stop the server when finished)
echo.
call npm start

:EOF
echo.
echo Script completed. 