// First, check if we have data in localStorage
const savedProducts = localStorage.getItem('furnitureProducts');
const savedCategories = localStorage.getItem('furnitureCategories');

// Define categories object
const categories = {
    chairs: {
        id: 'chairs',
        name: 'Chairs',
        count: 6,
        description: 'Comfortable and stylish chairs for your home or office. Our selection includes dining chairs, lounge chairs, and accent chairs.'
    },
    sofas: {
        id: 'sofas',
        name: 'Sofas',
        count: 7,
        description: 'Elegant and comfortable sofas to enhance your living room. Choose from various styles, materials, and colors.'
    },
    tables: {
        id: 'tables',
        name: 'Tables',
        count: 7,
        description: 'Functional and beautiful tables for dining, coffee, side tables and more. Various designs to match your décor.'
    },
    lighting: {
        id: 'lighting',
        name: 'Lighting',
        count: 0,
        description: 'Illuminate your space with our contemporary lighting solutions. Floor lamps, table lamps, and ceiling fixtures.'
    },
    accessories: {
        id: 'accessories',
        name: 'Accessories',
        count: 0,
        description: 'Complete your interior with our curated accessories. Decorative items to add personality to any room.'
    },
    bade: {
        id: 'bade',
        name: 'Beds',
        count: 7,
        description: 'Quality beds for restful sleep. Our collection includes various sizes and styles to suit any bedroom.'
    }
};

// Define default placeholder image (a simple gray square with text)
const defaultProductImage = "data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22300%22%20height%3D%22300%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Crect%20width%3D%22300%22%20height%3D%22300%22%20fill%3D%22%23cccccc%22%2F%3E%3Ctext%20fill%3D%22%23333333%22%20font-family%3D%22Arial%22%20font-size%3D%2220%22%20x%3D%2292%22%20y%3D%22150%22%3ENo%20Image%3C%2Ftext%3E%3C%2Fsvg%3E";

// Define products array with sample data
const products = [
    // Chairs
    {
        id: 'c1',
        name: 'Contemporary Dining Chair',
        category: 'chairs',
        description: 'A modern dining chair with a sleek design and comfortable cushion. Perfect for dining rooms and kitchen areas.',
        price: 129.99,
        image: 'image/chairs/OIP (9).jpg',
        featured: true,
        inStock: true,
        new: false,
        rating: 4.7,
        reviewCount: 18,
        specs: {
            dimensions: '45x50x85 cm',
            weight: '5 kg',
            material: 'Fabric, Metal',
            colors: ['Gray', 'Blue', 'Black']
        }
    },
    {
        id: 'c2',
        name: 'Ergonomic Office Chair',
        category: 'chairs',
        description: 'An ergonomic office chair designed for maximum comfort during long work hours. Features adjustable height and lumbar support.',
        price: 249.99,
        image: 'image/chairs/OIP (10).jpg',
        featured: false,
        inStock: true,
        new: true,
        rating: 4.8,
        reviewCount: 24,
        specs: {
            dimensions: '65x65x120 cm',
            weight: '12 kg',
            material: 'Mesh, Plastic, Metal',
            colors: ['Black', 'Gray']
        }
    },
    {
        id: 'c3',
        name: 'Accent Lounge Chair',
        category: 'chairs',
        description: 'A stylish accent chair that adds character to any living space. Perfect for reading corners or small spaces.',
        price: 179.99,
        image: 'image/chairs/OIP (11).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.5,
        reviewCount: 15,
        specs: {
            dimensions: '70x75x80 cm',
            weight: '8 kg',
            material: 'Fabric, Wood',
            colors: ['Teal', 'Mustard', 'Rose']
        }
    },
    {
        id: 'c4',
        name: 'Minimalist Wooden Chair',
        category: 'chairs',
        description: 'A minimalist wooden chair with clean lines and natural finish. Blends with various interior styles.',
        price: 99.99,
        image: 'image/chairs/OIP (12).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.3,
        reviewCount: 12,
        specs: {
            dimensions: '40x45x80 cm',
            weight: '4 kg',
            material: 'Solid Wood',
            colors: ['Natural', 'Walnut', 'White']
        }
    },
    {
        id: 'c5',
        name: 'Swivel Bar Stool',
        category: 'chairs',
        description: 'A modern bar stool with swivel function and comfortable seat. Perfect for kitchen islands and home bars.',
        price: 149.99,
        image: 'image/chairs/OIP (13).jpg',
        featured: false,
        inStock: true,
        new: true,
        rating: 4.6,
        reviewCount: 9,
        specs: {
            dimensions: '40x40x100 cm',
            weight: '6 kg',
            material: 'Faux Leather, Metal',
            colors: ['Black', 'White', 'Brown']
        }
    },
    {
        id: 'c6',
        name: 'Nordic Armchair',
        category: 'chairs',
        description: 'A cozy armchair inspired by Nordic design. Features comfortable cushioning and solid wood frame.',
        price: 199.99,
        image: 'image/chairs/OIP (14).jpg',
        featured: true,
        inStock: true,
        new: false,
        rating: 4.9,
        reviewCount: 21,
        specs: {
            dimensions: '75x80x85 cm',
            weight: '10 kg',
            material: 'Fabric, Solid Oak',
            colors: ['Light Gray', 'Dark Gray', 'Blue']
        }
    },

    // Sofas
    {
        id: 's1',
        name: 'Modern 3-Seater Sofa',
        category: 'sofas',
        description: 'A spacious 3-seater sofa with clean lines and premium upholstery. Perfect for contemporary living rooms.',
        price: 899.99,
        image: 'image/sofas/OIP (9).jpg',
        featured: true,
        inStock: true,
        new: false,
        rating: 4.8,
        reviewCount: 32,
        specs: {
            dimensions: '220x95x85 cm',
            weight: '45 kg',
            material: 'Premium Fabric, Hardwood Frame',
            colors: ['Gray', 'Blue', 'Beige', 'Green']
        }
    },
    {
        id: 's2',
        name: 'Sectional Corner Sofa',
        category: 'sofas',
        description: 'A versatile sectional sofa with modular design. Can be arranged in multiple configurations to suit your space.',
        price: 1299.99,
        image: 'image/sofas/OIP (10).jpg',
        featured: true,
        inStock: true,
        new: true,
        rating: 4.7,
        reviewCount: 28,
        specs: {
            dimensions: '320x170x85 cm',
            weight: '65 kg',
            material: 'Premium Fabric, Steel Frame',
            colors: ['Gray', 'Black', 'Navy']
        }
    },
    {
        id: 's3',
        name: 'Compact Loveseat',
        category: 'sofas',
        description: 'A cozy loveseat perfect for small spaces without compromising on style or comfort.',
        price: 599.99,
        image: 'image/sofas/OIP (11).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.4,
        reviewCount: 14,
        specs: {
            dimensions: '160x85x80 cm',
            weight: '35 kg',
            material: 'Fabric, Wooden Frame',
            colors: ['Light Gray', 'Beige', 'Mint']
        }
    },
    {
        id: 's4',
        name: 'Convertible Sofa Bed',
        category: 'sofas',
        description: 'A functional sofa that easily converts into a comfortable bed. Perfect for guest rooms and small apartments.',
        price: 849.99,
        image: 'image/sofas/OIP (12).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.5,
        reviewCount: 19,
        specs: {
            dimensions: '210x90x85 cm (sofa), 210x140x45 cm (bed)',
            weight: '50 kg',
            material: 'Fabric, Metal Frame',
            colors: ['Dark Gray', 'Blue', 'Brown']
        }
    },
    {
        id: 's5',
        name: 'Luxury Velvet Sofa',
        category: 'sofas',
        description: 'A luxurious velvet sofa with deep cushions and elegant design. Adds sophistication to any living space.',
        price: 1099.99,
        image: 'image/sofas/OIP (13).jpg',
        featured: true,
        inStock: true,
        new: true,
        rating: 4.9,
        reviewCount: 22,
        specs: {
            dimensions: '220x95x85 cm',
            weight: '55 kg',
            material: 'Velvet, Hardwood Frame',
            colors: ['Emerald', 'Navy', 'Burgundy', 'Gold']
        }
    },
    {
        id: 's6',
        name: 'Mid-Century Modern Sofa',
        category: 'sofas',
        description: 'A mid-century inspired sofa with tapered legs and tufted backrest. Combines vintage charm with modern comfort.',
        price: 949.99,
        image: 'image/sofas/download.jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.6,
        reviewCount: 17,
        specs: {
            dimensions: '200x85x80 cm',
            weight: '40 kg',
            material: 'Fabric, Solid Wood',
            colors: ['Gray', 'Blue', 'Orange', 'Green']
        }
    },
    {
        id: 's7',
        name: 'Chaise Lounge Sofa',
        category: 'sofas',
        description: 'A comfortable sofa with chaise extension, perfect for relaxing and stretching out.',
        price: 799.99,
        image: 'image/sofas/close-up-furniture-color-palette-free-photo.jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.5,
        reviewCount: 16,
        specs: {
            dimensions: '240x95x85 cm',
            weight: '48 kg',
            material: 'Fabric, Hardwood Frame',
            colors: ['Light Gray', 'Dark Gray', 'Blue']
        }
    },

    // Tables
    {
        id: 't1',
        name: 'Modern Dining Table',
        category: 'tables',
        description: 'A sleek dining table with clean lines and durable materials. Seats up to 6 people comfortably.',
        price: 499.99,
        image: 'image/tables/OIP (2).jpg',
        featured: true,
        inStock: true,
        new: false,
        rating: 4.7,
        reviewCount: 23,
        specs: {
            dimensions: '160x90x75 cm',
            weight: '35 kg',
            material: 'MDF, Metal',
            colors: ['White', 'Black', 'Oak']
        }
    },
    {
        id: 't2',
        name: 'Coffee Table with Storage',
        category: 'tables',
        description: 'A functional coffee table with hidden storage compartments. Perfect for keeping your living room organized.',
        price: 299.99,
        image: 'image/tables/OIP (3).jpg',
        featured: false,
        inStock: true,
        new: true,
        rating: 4.6,
        reviewCount: 18,
        specs: {
            dimensions: '120x60x45 cm',
            weight: '25 kg',
            material: 'MDF, Wood Veneer',
            colors: ['Walnut', 'White', 'Black']
        }
    },
    {
        id: 't3',
        name: 'Round Side Table',
        category: 'tables',
        description: 'A compact side table with round top and sleek metal legs. Perfect next to sofas or as a nightstand.',
        price: 149.99,
        image: 'image/tables/OIP (4).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.4,
        reviewCount: 12,
        specs: {
            dimensions: '45x45x50 cm',
            weight: '5 kg',
            material: 'MDF, Metal',
            colors: ['White', 'Black', 'Gold']
        }
    },
    {
        id: 't4',
        name: 'Extendable Dining Table',
        category: 'tables',
        description: 'A versatile dining table that extends to accommodate extra guests. Perfect for spaces that need flexibility.',
        price: 649.99,
        image: 'image/tables/OIP (5).jpg',
        featured: true,
        inStock: true,
        new: false,
        rating: 4.8,
        reviewCount: 26,
        specs: {
            dimensions: '180-240x90x75 cm',
            weight: '45 kg',
            material: 'Solid Wood, MDF',
            colors: ['Oak', 'Walnut', 'White']
        }
    },
    {
        id: 't5',
        name: 'Marble Top Console Table',
        category: 'tables',
        description: 'An elegant console table with marble top and metal frame. Adds sophistication to entryways and living rooms.',
        price: 379.99,
        image: 'image/tables/OIP (6).jpg',
        featured: false,
        inStock: true,
        new: true,
        rating: 4.9,
        reviewCount: 14,
        specs: {
            dimensions: '120x35x80 cm',
            weight: '20 kg',
            material: 'Marble, Metal',
            colors: ['White/Gold', 'Black/Silver', 'Green/Brass']
        }
    },
    {
        id: 't6',
        name: 'Nesting Coffee Tables',
        category: 'tables',
        description: 'A set of nesting coffee tables that can be separated or combined as needed. Versatile and space-saving.',
        price: 249.99,
        image: 'image/tables/OIP (7).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.5,
        reviewCount: 19,
        specs: {
            dimensions: 'Large: 90x50x45 cm, Small: 70x40x40 cm',
            weight: '15 kg (set)',
            material: 'MDF, Metal',
            colors: ['Black', 'White/Oak', 'Walnut']
        }
    },
    {
        id: 't7',
        name: 'Industrial Dining Table',
        category: 'tables',
        description: 'A sturdy dining table with industrial-inspired design. Features solid wood top and metal frame.',
        price: 599.99,
        image: 'image/tables/OIP (8).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.7,
        reviewCount: 21,
        specs: {
            dimensions: '180x90x75 cm',
            weight: '40 kg',
            material: 'Solid Wood, Metal',
            colors: ['Rustic Brown/Black']
        }
    },

    // Beds
    {
        id: 'b1',
        name: 'Queen Size Platform Bed',
        category: 'bade',
        description: 'A modern queen-size platform bed with clean lines and solid construction. No box spring needed.',
        price: 699.99,
        image: 'image/bade/OIP (2).jpg',
        featured: true,
        inStock: true,
        new: false,
        rating: 4.8,
        reviewCount: 29,
        specs: {
            dimensions: '160x200 cm',
            weight: '50 kg',
            material: 'Solid Wood, MDF',
            colors: ['Walnut', 'White', 'Black']
        }
    },
    {
        id: 'b2',
        name: 'King Size Upholstered Bed',
        category: 'bade',
        description: 'A luxurious king-size bed with upholstered headboard for extra comfort and style.',
        price: 899.99,
        image: 'image/bade/OIP (3).jpg',
        featured: true,
        inStock: true,
        new: true,
        rating: 4.9,
        reviewCount: 24,
        specs: {
            dimensions: '180x200 cm',
            weight: '60 kg',
            material: 'Fabric, Solid Wood',
            colors: ['Gray', 'Beige', 'Blue']
        }
    },
    {
        id: 'b3',
        name: 'Single Bed with Storage',
        category: 'bade',
        description: 'A practical single bed with built-in storage drawers underneath. Perfect for small bedrooms.',
        price: 499.99,
        image: 'image/bade/OIP (4).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.6,
        reviewCount: 18,
        specs: {
            dimensions: '90x200 cm',
            weight: '40 kg',
            material: 'MDF, Solid Wood',
            colors: ['White', 'Oak', 'Walnut']
        }
    },
    {
        id: 'b4',
        name: 'Double Canopy Bed',
        category: 'bade',
        description: 'An elegant canopy bed that adds a touch of luxury to any bedroom. Features a solid frame and classic design.',
        price: 1099.99,
        image: 'image/bade/OIP (5).jpg',
        featured: false,
        inStock: true,
        new: true,
        rating: 4.8,
        reviewCount: 15,
        specs: {
            dimensions: '140x200 cm',
            weight: '70 kg',
            material: 'Solid Wood, Metal',
            colors: ['Black', 'White', 'Gold']
        }
    },
    {
        id: 'b5',
        name: 'Mid-Century Modern Bed',
        category: 'bade',
        description: 'A stylish bed inspired by mid-century design with tapered legs and simple headboard.',
        price: 749.99,
        image: 'image/bade/OIP (6).jpg',
        featured: true,
        inStock: true,
        new: false,
        rating: 4.7,
        reviewCount: 22,
        specs: {
            dimensions: '160x200 cm',
            weight: '45 kg',
            material: 'Solid Wood',
            colors: ['Walnut', 'Oak']
        }
    },
    {
        id: 'b6',
        name: 'Adjustable Bed Frame',
        category: 'bade',
        description: 'An electric adjustable bed frame that can be customized for optimal comfort. Multiple positions available.',
        price: 1299.99,
        image: 'image/bade/OIP (7).jpg',
        featured: false,
        inStock: true,
        new: true,
        rating: 4.9,
        reviewCount: 17,
        specs: {
            dimensions: '160x200 cm',
            weight: '80 kg',
            material: 'Metal, Fabric',
            colors: ['Gray', 'Black']
        }
    },
    {
        id: 'b7',
        name: 'Minimalist Platform Bed',
        category: 'bade',
        description: 'A low-profile platform bed with minimalist design. Adds a modern touch to any bedroom.',
        price: 599.99,
        image: 'image/bade/OIP (8).jpg',
        featured: false,
        inStock: true,
        new: false,
        rating: 4.5,
        reviewCount: 20,
        specs: {
            dimensions: '160x200 cm',
            weight: '40 kg',
            material: 'MDF, Solid Wood',
            colors: ['White', 'Black', 'Oak']
        }
    }
];

// Override with saved data if available
if (savedProducts) {
    try {
        const parsedProducts = JSON.parse(savedProducts);
        products.length = 0; // Clear the array
        parsedProducts.forEach(product => {
            // Validate image - ensure it's not undefined or empty
            if (!product.image || product.image === "") {
                product.image = defaultProductImage;
            }
            products.push(product);
        });
        console.log('Products loaded from localStorage:', products.length);
    } catch (error) {
        console.error('Error parsing saved products:', error);
    }
}

if (savedCategories) {
    try {
        const parsedCategories = JSON.parse(savedCategories);
        Object.keys(parsedCategories).forEach(key => {
            if (categories[key]) {
                categories[key] = parsedCategories[key];
            }
        });
        console.log('Categories loaded from localStorage');
    } catch (error) {
        console.error('Error parsing saved categories:', error);
    }
}

// Company information
const companyInfo = {
    name: 'asamere Furniture',
    slogan: 'Quality Furniture for Modern Living',
    description: 'asamere Furniture specializes in creating high-quality, stylish furniture for modern homes. Our pieces combine contemporary design with exceptional craftsmanship.',
    yearFounded: 2010,
    email: 'wu7mufay@gmail.com',
    phone: '0960733342',
    address: 'Ethiopia, Addis Ababa, Gulele, Kechene'
};

// Function to sort products based on criteria
function sortProducts(products, sortBy) {
    const sortedProducts = [...products]; // Create a copy to avoid mutating the original array
    
    switch(sortBy) {
        case 'price-low':
            return sortedProducts.sort((a, b) => a.price - b.price);
        case 'price-high':
            return sortedProducts.sort((a, b) => b.price - a.price);
        case 'name':
            return sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
        case 'rating':
            return sortedProducts.sort((a, b) => b.rating - a.rating);
        case 'newest':
            return sortedProducts.sort((a, b) => b.new - a.new);
        default:
            // Default sorting logic (by date, featured, etc.)
            return sortedProducts;
    }
}

// Create furnitureDB object to expose methods for accessing the data
const furnitureDB = {
    // Method to get all products
    getAllProducts: function() {
        return products;
    },
    
    // Method to get a specific product by ID
    getProductById: function(id) {
        return products.find(product => product.id === id);
    },
    
    // Method to get products by category
    getProductsByCategory: function(category) {
        if (!category) {
            return products;
        }
        return products.filter(product => product.category === category);
    },
    
    // Method to get featured products
    getFeaturedProducts: function() {
        return products.filter(product => product.featured);
    },
    
    // Method to get new arrivals
    getNewArrivals: function() {
        return products.filter(product => product.new);
    },
    
    // Method to get all categories
    getCategories: function() {
        return categories;
    },
    
    // Method to get a specific category by ID
    getCategoryById: function(categoryId) {
        return categories[categoryId];
    },
    
    // Method to search products
    searchProducts: function(searchTerm) {
        if (!searchTerm) {
            return products;
        }
        
        const term = searchTerm.toLowerCase();
        return products.filter(product => 
            product.name.toLowerCase().includes(term) || 
            product.description.toLowerCase().includes(term) ||
            product.category.toLowerCase().includes(term)
        );
    },
    
    // Method to sort products
    sortProducts: sortProducts,
    
    // Company information
    companyInfo: companyInfo
};

// For backward compatibility
const productsData = products;
const categoryData = Object.keys(categories); 