// JavaScript for the product detail page

document.addEventListener('DOMContentLoaded', async function() {
    console.log('Product page loaded, initializing...');
    
    // Initialize mobile navigation
    initMobileNav();
    
    // Get product ID from URL
    const productId = getProductIdFromUrl();
    console.log('Product ID from URL:', productId);
    
    if (productId) {
        // Load product details
        await loadProductDetails(productId);
        
        // Load related products
        await loadRelatedProducts(productId);
    } else {
        console.warn('No product ID found in URL');
        document.querySelector('main').innerHTML = `
            <div class="container" style="padding: 6rem 0;">
                <div style="text-align: center;">
                    <h2>Product Not Found</h2>
                    <p>The product you're looking for could not be found.</p>
                    <a href="products.html" class="btn btn-primary" style="margin-top: 2rem;">Browse Products</a>
                </div>
            </div>
        `;
    }
    
    // Apply animations
    initAnimations();
});

// Initialize mobile navigation
function initMobileNav() {
    const mobileToggle = document.getElementById('mobileToggle');
    const mainNav = document.getElementById('mainNav');
    
    if (mobileToggle && mainNav) {
        mobileToggle.addEventListener('click', () => {
            mainNav.classList.toggle('active');
            mobileToggle.classList.toggle('active');
        });
    }
}

// Get product ID from URL query parameters
function getProductIdFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id');
}

// Load product details
async function loadProductDetails(productId) {
    try {
        console.log('Loading product details for ID:', productId);
        
        // Try to load from API first, fall back to local data
        let product;
        
        try {
            console.log('Attempting to load product from API');
            product = await API.getProductById(productId);
        } catch (apiError) {
            console.log('API error, using local data', apiError);
            product = furnitureDB.getProductById(productId);
        }
        
        console.log('Product data:', product);
        
        if (!product) {
            console.error('Product not found for ID:', productId);
            document.querySelector('main').innerHTML = `
                <div class="container" style="padding: 6rem 0;">
                    <div style="text-align: center;">
                        <h2>Product Not Found</h2>
                        <p>The product you're looking for could not be found.</p>
                        <a href="products.html" class="btn btn-primary" style="margin-top: 2rem;">Browse Products</a>
                    </div>
                </div>
            `;
            return;
        }
        
        // Update page title
        document.title = `${product.name} - asamere`;
        
        // Get category name based on category ID
        let categoryName = '';
        switch(product.category) {
            case 'chairs': categoryName = 'Chairs'; break;
            case 'sofas': categoryName = 'Sofas'; break;
            case 'tables': categoryName = 'Tables'; break;
            case 'lighting': categoryName = 'Lighting'; break;
            case 'accessories': categoryName = 'Accessories'; break;
            case 'bade': categoryName = 'Beds'; break;
            default: categoryName = product.category.charAt(0).toUpperCase() + product.category.slice(1);
        }
        
        const categoryClass = getCategoryClass(product.category);
        
        console.log('Category info:', { category: product.category, name: categoryName, class: categoryClass });
        
        // Parse specs if they're stored as a string
        let specs = product.specs;
        if (typeof specs === 'string') {
            try {
                specs = JSON.parse(specs);
            } catch (e) {
                console.error('Error parsing specs JSON:', e);
                specs = { dimensions: 'N/A', weight: 'N/A', material: 'N/A', colors: ['N/A'] };
            }
        }
        
        // Use default specs if not available
        if (!specs) {
            specs = { dimensions: 'N/A', weight: 'N/A', material: 'N/A', colors: ['N/A'] };
        }
        
        // Ensure colors is an array
        if (!specs.colors) {
            specs.colors = ['N/A'];
        } else if (typeof specs.colors === 'string') {
            specs.colors = specs.colors.split(',').map(color => color.trim());
        }
        
        // Generate HTML for product details
        const productDetailHTML = `
            <section class="product-detail">
                <div class="product-detail-image">
                    <img src="${product.image}" alt="${product.name}">
                </div>
                <div class="product-detail-info">
                    <span class="product-detail-category ${categoryClass}">
                        <a href="products.html?category=${product.category}">${categoryName}</a>
                    </span>
                    <h1>${product.name}</h1>
                    <div class="product-detail-price">ETB ${parseFloat(product.price).toFixed(2)}</div>
                    <div class="product-detail-description">
                        ${product.description}
                    </div>
                    <div class="product-detail-actions">
                        <a href="#" class="btn btn-primary">Add to Cart</a>
                        <a href="#" class="btn btn-secondary">Add to Wishlist</a>
                    </div>
                    <div class="product-detail-features">
                        <h3>Product Specifications</h3>
                        <ul style="list-style: none; padding: 0; margin: 1rem 0;">
                            <li style="margin-bottom: 0.5rem;"><i class="fas fa-check" style="color: var(--accent-color3); margin-right: 0.5rem;"></i> <strong>Dimensions:</strong> ${specs.dimensions || 'N/A'}</li>
                            <li style="margin-bottom: 0.5rem;"><i class="fas fa-check" style="color: var(--accent-color3); margin-right: 0.5rem;"></i> <strong>Weight:</strong> ${specs.weight || 'N/A'}</li>
                            <li style="margin-bottom: 0.5rem;"><i class="fas fa-check" style="color: var(--accent-color3); margin-right: 0.5rem;"></i> <strong>Material:</strong> ${specs.material || 'N/A'}</li>
                            <li style="margin-bottom: 0.5rem;"><i class="fas fa-check" style="color: var(--accent-color3); margin-right: 0.5rem;"></i> <strong>Available Colors:</strong> ${specs.colors.join(', ')}</li>
                        </ul>
                    </div>
                </div>
            </section>
        `;
        
        // Update the main section
        const mainSection = document.querySelector('main');
        mainSection.innerHTML = `
            <div class="container">
                ${productDetailHTML}
            </div>
        `;
        console.log('Product details rendered successfully');
    } catch (error) {
        console.error('Error loading product details:', error);
    }
}

// Load related products
async function loadRelatedProducts(currentProductId) {
    try {
        console.log('Loading related products for ID:', currentProductId);
        
        // Try to load from API first, fall back to local data
        let allProducts;
        let currentProduct;
        
        try {
            console.log('Attempting to load related products from API');
            allProducts = await API.getAllProducts();
            currentProduct = await API.getProductById(currentProductId);
        } catch (apiError) {
            console.log('API error, using local data for related products', apiError);
            allProducts = furnitureDB.getAllProducts();
            currentProduct = furnitureDB.getProductById(currentProductId);
        }
        
        if (!currentProduct) {
            console.warn('Current product not found, cannot load related products');
            return;
        }
        
        // Filter products in the same category, excluding the current product
        const relatedProducts = allProducts
            .filter(product => product.category === currentProduct.category && product.id !== currentProductId)
            .slice(0, 3); // Limit to 3 related products
        
        console.log(`Found ${relatedProducts.length} related products for category: ${currentProduct.category}`);
        
        if (relatedProducts.length === 0) {
            console.log('No related products found');
            return;
        }
        
        // Generate HTML for related products
        let relatedProductsHTML = '';
        
        relatedProducts.forEach(product => {
            const categoryClass = getCategoryClass(product.category);
            
            relatedProductsHTML += `
                <div class="product-card reveal-animation">
                    <div class="product-image">
                        <img src="${product.image}" alt="${product.name}" loading="lazy">
                        <div class="product-quick-actions">
                            <button class="action-btn" title="Quick View">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn" title="Add to Wishlist">
                                <i class="fas fa-heart"></i>
                            </button>
                        </div>
                    </div>
                    <div class="product-info">
                        <span class="category-tag ${categoryClass}">${getCategoryName(product.category)}</span>
                        <h3>${product.name}</h3>
                        <p>${limitText(product.description, 100)}</p>
                        <div class="product-meta">
                            <span class="product-price">ETB ${parseFloat(product.price).toFixed(2)}</span>
                            <a href="product.html?id=${product.id}" class="btn btn-primary btn-sm">View Details</a>
                        </div>
                    </div>
                </div>
            `;
        });
        
        // Add related products section to the main section
        const mainSection = document.querySelector('main');
        
        mainSection.innerHTML += `
            <div class="container" style="margin-top: 4rem;">
                <div class="section-title reveal-animation">
                    <span style="display: inline-block; padding: 0.3rem 1rem; background: rgba(59, 130, 246, 0.1); border-radius: 30px; font-size: 0.8rem; color: var(--accent-color); margin-bottom: 1rem; font-weight: 500;">RELATED ITEMS</span>
                    <h2>You Might Also Like</h2>
                    <p>Similar products you might be interested in</p>
                </div>
                <div class="products-grid">
                    ${relatedProductsHTML}
                </div>
            </div>
        `;
        console.log('Related products rendered successfully');
    } catch (error) {
        console.error('Error loading related products:', error);
    }
}

// Initialize animations
function initAnimations() {
    const revealAnimations = document.querySelectorAll('.reveal-animation');
    
    const revealCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    };
    
    const revealObserver = new IntersectionObserver(revealCallback, {
        threshold: 0.1
    });
    
    revealAnimations.forEach(animation => {
        revealObserver.observe(animation);
    });
}

// Helper function to get CSS class for category tag
function getCategoryClass(category) {
    switch(category) {
        case 'chairs': return 'bg-chairs';
        case 'sofas': return 'bg-sofas';
        case 'tables': return 'bg-tables';
        case 'lighting': return 'bg-lighting';
        case 'accessories': return 'bg-accessories';
        case 'bade': return 'bg-bade';
        default: return 'bg-chairs';
    }
}

// Helper function to get category display name
function getCategoryName(categoryId) {
    const categories = furnitureDB.getCategories();
    return categories[categoryId] ? categories[categoryId].name : categoryId;
}

// Helper function to limit text length
function limitText(text, limit) {
    if (text.length <= limit) return text;
    return text.substring(0, limit) + '...';
} 