// API client for MongoDB integration
const mongoDBClient = {
    // Base URL for API endpoints
    baseUrl: 'http://localhost:5000/api',
    
    // Method to check if the API is available
    isApiAvailable: async function() {
        try {
            const response = await fetch(`${this.baseUrl}/health-check`, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });
            return response.ok;
        } catch (error) {
            console.log('API not available, using local data', error);
            return false;
        }
    },
    
    // Products
    getAllProducts: async function() {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.getAllProducts();
            }
            
            const response = await fetch(`${this.baseUrl}/products`);
            if (!response.ok) throw new Error('Failed to fetch products');
            return await response.json();
        } catch (error) {
            console.error('Error fetching products:', error);
            return furnitureDB.getAllProducts();
        }
    },
    
    getProductById: async function(id) {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.getProductById(id);
            }
            
            const response = await fetch(`${this.baseUrl}/products/${id}`);
            if (!response.ok) throw new Error(`Failed to fetch product with ID ${id}`);
            return await response.json();
        } catch (error) {
            console.error(`Error fetching product with ID ${id}:`, error);
            return furnitureDB.getProductById(id);
        }
    },
    
    getProductsByCategory: async function(category) {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.getProductsByCategory(category);
            }
            
            const response = await fetch(`${this.baseUrl}/products/category/${category}`);
            if (!response.ok) throw new Error(`Failed to fetch products in category ${category}`);
            return await response.json();
        } catch (error) {
            console.error(`Error fetching products in category ${category}:`, error);
            return furnitureDB.getProductsByCategory(category);
        }
    },
    
    getFeaturedProducts: async function() {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.getFeaturedProducts();
            }
            
            const response = await fetch(`${this.baseUrl}/products/featured/items`);
            if (!response.ok) throw new Error('Failed to fetch featured products');
            return await response.json();
        } catch (error) {
            console.error('Error fetching featured products:', error);
            return furnitureDB.getFeaturedProducts();
        }
    },
    
    getNewArrivals: async function() {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.getNewArrivals();
            }
            
            const response = await fetch(`${this.baseUrl}/products/new/arrivals`);
            if (!response.ok) throw new Error('Failed to fetch new arrivals');
            return await response.json();
        } catch (error) {
            console.error('Error fetching new arrivals:', error);
            return furnitureDB.getNewArrivals();
        }
    },
    
    searchProducts: async function(searchTerm) {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.searchProducts(searchTerm);
            }
            
            const response = await fetch(`${this.baseUrl}/products/search/items?term=${encodeURIComponent(searchTerm)}`);
            if (!response.ok) throw new Error('Failed to search products');
            return await response.json();
        } catch (error) {
            console.error('Error searching products:', error);
            return furnitureDB.searchProducts(searchTerm);
        }
    },
    
    createProduct: async function(productData) {
        try {
            if (!(await this.isApiAvailable())) {
                console.error('API not available, cannot create product');
                return null;
            }
            
            const response = await fetch(`${this.baseUrl}/products`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });
            
            if (!response.ok) throw new Error('Failed to create product');
            return await response.json();
        } catch (error) {
            console.error('Error creating product:', error);
            return null;
        }
    },
    
    updateProduct: async function(id, productData) {
        try {
            if (!(await this.isApiAvailable())) {
                console.error('API not available, cannot update product');
                return null;
            }
            
            const response = await fetch(`${this.baseUrl}/products/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });
            
            if (!response.ok) throw new Error(`Failed to update product with ID ${id}`);
            return await response.json();
        } catch (error) {
            console.error(`Error updating product with ID ${id}:`, error);
            return null;
        }
    },
    
    deleteProduct: async function(id) {
        try {
            if (!(await this.isApiAvailable())) {
                console.error('API not available, cannot delete product');
                return false;
            }
            
            const response = await fetch(`${this.baseUrl}/products/${id}`, {
                method: 'DELETE'
            });
            
            return response.ok;
        } catch (error) {
            console.error(`Error deleting product with ID ${id}:`, error);
            return false;
        }
    },
    
    // Categories
    getCategories: async function() {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.getCategories();
            }
            
            const response = await fetch(`${this.baseUrl}/categories`);
            if (!response.ok) throw new Error('Failed to fetch categories');
            return await response.json();
        } catch (error) {
            console.error('Error fetching categories:', error);
            return furnitureDB.getCategories();
        }
    },
    
    getCategoryById: async function(categoryId) {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.getCategoryById(categoryId);
            }
            
            const response = await fetch(`${this.baseUrl}/categories/${categoryId}`);
            if (!response.ok) throw new Error(`Failed to fetch category with ID ${categoryId}`);
            return await response.json();
        } catch (error) {
            console.error(`Error fetching category with ID ${categoryId}:`, error);
            return furnitureDB.getCategoryById(categoryId);
        }
    },
    
    // Company Info
    getCompanyInfo: async function() {
        try {
            if (!(await this.isApiAvailable())) {
                return furnitureDB.companyInfo;
            }
            
            const response = await fetch(`${this.baseUrl}/company`);
            if (!response.ok) throw new Error('Failed to fetch company information');
            return await response.json();
        } catch (error) {
            console.error('Error fetching company information:', error);
            return furnitureDB.companyInfo;
        }
    },
    
    updateCompanyInfo: async function(companyData) {
        try {
            if (!(await this.isApiAvailable())) {
                console.error('API not available, cannot update company information');
                return null;
            }
            
            const response = await fetch(`${this.baseUrl}/company`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(companyData)
            });
            
            if (!response.ok) throw new Error('Failed to update company information');
            return await response.json();
        } catch (error) {
            console.error('Error updating company information:', error);
            return null;
        }
    }
};

// For browser console testing
window.mongoDBClient = mongoDBClient;

// API Client for asamere Furniture
const API = (function() {
    // Base URL for API requests
    const BASE_URL = 'http://localhost:5000/api';
    
    /**
     * Generic fetch wrapper with error handling
     * @param {string} endpoint - API endpoint
     * @param {object} options - Fetch options
     * @returns {Promise<any>} - JSON response
     */
    async function fetchApi(endpoint, options = {}) {
        console.log(`API request to ${endpoint}`, options);
        
        try {
            const url = `${BASE_URL}${endpoint}`;
            console.log('Fetching from URL:', url);
            
            const response = await fetch(url, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });
            
            console.log(`Response status: ${response.status}`);
            
            if (!response.ok) {
                let errorText;
                try {
                    errorText = await response.text();
                } catch (e) {
                    errorText = 'Failed to parse error response';
                }
                console.error(`API Error (${response.status}): ${errorText}`);
                throw new Error(`API Error (${response.status}): ${errorText}`);
            }
            
            try {
                const data = await response.json();
                console.log('API response data:', data);
                return data;
            } catch (jsonError) {
                console.error('Error parsing JSON response:', jsonError);
                throw new Error('Invalid JSON response from API');
            }
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }
    
    /**
     * Get all products
     * @returns {Promise<Array>} - Array of products
     */
    async function getAllProducts() {
        return fetchApi('/products');
    }
    
    /**
     * Get product by ID
     * @param {string} id - Product ID
     * @returns {Promise<object>} - Product data
     */
    async function getProductById(id) {
        return fetchApi(`/products/${id}`);
    }
    
    /**
     * Get products by category
     * @param {string} category - Category ID
     * @returns {Promise<Array>} - Array of products in the category
     */
    async function getProductsByCategory(category) {
        if (!category) {
            return getAllProducts();
        }
        return fetchApi(`/products/category/${category}`);
    }
    
    /**
     * Get featured products
     * @returns {Promise<Array>} - Array of featured products
     */
    async function getFeaturedProducts() {
        return fetchApi('/products/featured/items');
    }
    
    /**
     * Get new arrivals
     * @returns {Promise<Array>} - Array of new products
     */
    async function getNewArrivals() {
        return fetchApi('/products/new/arrivals');
    }
    
    /**
     * Search products
     * @param {string} term - Search term
     * @returns {Promise<Array>} - Array of matching products
     */
    async function searchProducts(term) {
        return fetchApi(`/products/search/items?term=${encodeURIComponent(term)}`);
    }
    
    /**
     * Get all categories
     * @returns {Promise<object>} - Categories object
     */
    async function getCategories() {
        return fetchApi('/categories');
    }
    
    /**
     * Get category by ID
     * @param {string} id - Category ID
     * @returns {Promise<object>} - Category data
     */
    async function getCategoryById(id) {
        return fetchApi(`/categories/${id}`);
    }
    
    /**
     * Create a new product
     * @param {object} productData - Product data
     * @returns {Promise<object>} - Created product response
     */
    async function createProduct(productData) {
        return fetchApi('/products', {
            method: 'POST',
            body: JSON.stringify(productData)
        });
    }
    
    /**
     * Update a product
     * @param {string} id - Product ID
     * @param {object} productData - Updated product data
     * @returns {Promise<object>} - Update response
     */
    async function updateProduct(id, productData) {
        return fetchApi(`/products/${id}`, {
            method: 'PUT',
            body: JSON.stringify(productData)
        });
    }
    
    /**
     * Delete a product
     * @param {string} id - Product ID
     * @returns {Promise<object>} - Delete response
     */
    async function deleteProduct(id) {
        return fetchApi(`/products/${id}`, {
            method: 'DELETE'
        });
    }
    
    /**
     * Sort products by given criteria
     * @param {Array} products - Array of products to sort
     * @param {string} sortBy - Sort criteria (price-asc, price-desc, newest, name-asc, name-desc, rating)
     * @returns {Array} - Sorted products array
     */
    function sortProducts(products, sortBy = 'newest') {
        console.log('Sorting products by:', sortBy);
        console.log('Original products:', products);
        
        if (!products || !Array.isArray(products)) {
            console.warn('Products is not an array or is undefined', products);
            return [];
        }
        
        if (products.length === 0) {
            console.log('Products array is empty, nothing to sort');
            return [];
        }
        
        const productsCopy = [...products];
        
        try {
            switch (sortBy) {
                case 'price-asc':
                    return productsCopy.sort((a, b) => parseFloat(a.price || 0) - parseFloat(b.price || 0));
                case 'price-desc':
                    return productsCopy.sort((a, b) => parseFloat(b.price || 0) - parseFloat(a.price || 0));
                case 'name-asc':
                    return productsCopy.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
                case 'name-desc':
                    return productsCopy.sort((a, b) => (b.name || '').localeCompare(a.name || ''));
                case 'rating':
                    return productsCopy.sort((a, b) => parseFloat(b.rating || 0) - parseFloat(a.rating || 0));
                case 'newest':
                default:
                    // Assuming newer products have the 'new' flag
                    return productsCopy.sort((a, b) => {
                        if (a.new && !b.new) return -1;
                        if (!a.new && b.new) return 1;
                        return 0;
                    });
            }
        } catch (error) {
            console.error('Error during sort:', error);
            return productsCopy; // Return unsorted copy on error
        }
    }
    
    // Public API
    return {
        getAllProducts,
        getProductById,
        getProductsByCategory,
        getFeaturedProducts,
        getNewArrivals,
        searchProducts,
        getCategories,
        getCategoryById,
        createProduct,
        updateProduct,
        deleteProduct,
        sortProducts
    };
})();
