/**
 * Inventory Management System
 * This file provides functionality for the inventory management section of the admin panel
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the inventory management system
    initMobileNav();
    loadInventoryData();
    loadCategories();
    updateInventoryStats();
    
    // Set up event listeners
    document.getElementById('categoryFilter').addEventListener('change', filterInventory);
    document.getElementById('stockFilter').addEventListener('change', filterInventory);
    document.getElementById('searchBtn').addEventListener('click', filterInventory);
    document.getElementById('searchInventory').addEventListener('keyup', function(event) {
        if (event.key === 'Enter') {
            filterInventory();
        }
    });
    
    // Modal functionality
    const modal = document.getElementById('stockUpdateModal');
    const closeButtons = document.querySelectorAll('.close-modal');
    
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            modal.style.display = 'none';
        });
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
    
    document.getElementById('stockUpdateForm').addEventListener('submit', function(e) {
        e.preventDefault();
        updateProductStock();
        modal.style.display = 'none';
    });
});

/**
 * Initialize mobile navigation
 */
function initMobileNav() {
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.querySelector('.admin-sidebar');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            mobileMenu.classList.toggle('active');
        });
    }
}

/**
 * Load inventory data from the database and display it in the table
 */
function loadInventoryData() {
    const tableBody = document.getElementById('inventoryTableBody');
    tableBody.innerHTML = '';
    
    // Get products from the database
    const products = furnitureDB.getAllProducts();
    
    // Create a simulated inventory system with random stock levels
    let inventoryData = [];
    
    products.forEach(product => {
        // For demo purposes, we'll create varying stock levels
        const stockLevel = Math.floor(Math.random() * 50) + 1;
        
        // Determine stock status
        let stockStatus = '';
        let statusClass = '';
        
        if (stockLevel > 10) {
            stockStatus = 'In Stock';
            statusClass = 'in-stock';
        } else if (stockLevel > 0) {
            stockStatus = 'Low Stock';
            statusClass = 'low-stock';
        } else {
            stockStatus = 'Out of Stock';
            statusClass = 'out-of-stock';
        }
        
        // Create a date for last update (random date within the last month)
        const lastUpdate = new Date();
        lastUpdate.setDate(lastUpdate.getDate() - Math.floor(Math.random() * 30));
        const formattedDate = lastUpdate.toLocaleDateString();
        
        inventoryData.push({
            id: product.id,
            name: product.name,
            category: product.category,
            stockLevel: stockLevel,
            stockStatus: stockStatus,
            statusClass: statusClass,
            lastUpdate: formattedDate,
            image: product.image
        });
    });
    
    // Sort inventory data by stock status (low stock and out of stock first)
    inventoryData.sort((a, b) => {
        if (a.stockStatus === 'Out of Stock' && b.stockStatus !== 'Out of Stock') return -1;
        if (a.stockStatus !== 'Out of Stock' && b.stockStatus === 'Out of Stock') return 1;
        if (a.stockStatus === 'Low Stock' && b.stockStatus === 'In Stock') return -1;
        if (a.stockStatus === 'In Stock' && b.stockStatus === 'Low Stock') return 1;
        return 0;
    });
    
    // Display inventory data in the table
    inventoryData.forEach(item => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${item.id}</td>
            <td>
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <img src="${item.image}" alt="${item.name}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                    <span>${item.name}</span>
                </div>
            </td>
            <td>${capitalizeFirstLetter(item.category)}</td>
            <td>${item.stockLevel}</td>
            <td><span class="stock-status ${item.statusClass}">${item.stockStatus}</span></td>
            <td>${item.lastUpdate}</td>
            <td class="inventory-actions">
                <button class="btn btn-secondary" onclick="openStockUpdateModal('${item.id}', '${item.name}', ${item.stockLevel})">
                    <i class="fas fa-edit"></i> Update
                </button>
                <button class="btn btn-secondary" onclick="viewStockHistory('${item.id}')">
                    <i class="fas fa-history"></i> History
                </button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

/**
 * Load categories from the database and populate the category filter dropdown
 */
function loadCategories() {
    const categoryFilter = document.getElementById('categoryFilter');
    const categories = furnitureDB.getCategories();
    
    Object.keys(categories).forEach(categoryId => {
        const option = document.createElement('option');
        option.value = categoryId;
        option.textContent = categories[categoryId].name;
        categoryFilter.appendChild(option);
    });
}

/**
 * Filter inventory table based on selected category, stock status, and search term
 */
function filterInventory() {
    const categoryFilter = document.getElementById('categoryFilter').value;
    const stockFilter = document.getElementById('stockFilter').value;
    const searchTerm = document.getElementById('searchInventory').value.toLowerCase();
    
    const rows = document.querySelectorAll('#inventoryTableBody tr');
    
    rows.forEach(row => {
        const category = row.cells[2].textContent.toLowerCase();
        const stockStatus = row.cells[4].textContent.trim();
        const productName = row.cells[1].textContent.trim().toLowerCase();
        const productId = row.cells[0].textContent;
        
        let showRow = true;
        
        if (categoryFilter) {
            const selectedCategory = document.querySelector(`#categoryFilter option[value="${categoryFilter}"]`).textContent.toLowerCase();
            if (category !== selectedCategory) {
                showRow = false;
            }
        }
        
        if (stockFilter) {
            if (stockFilter === 'inStock' && stockStatus !== 'In Stock') {
                showRow = false;
            } else if (stockFilter === 'lowStock' && stockStatus !== 'Low Stock') {
                showRow = false;
            } else if (stockFilter === 'outOfStock' && stockStatus !== 'Out of Stock') {
                showRow = false;
            }
        }
        
        if (searchTerm && !productName.includes(searchTerm) && !productId.includes(searchTerm)) {
            showRow = false;
        }
        
        row.style.display = showRow ? '' : 'none';
    });
    
    // Update the visible count
    updateVisibleCount();
}

/**
 * Update the count of visible products after filtering
 */
function updateVisibleCount() {
    const visibleRows = document.querySelectorAll('#inventoryTableBody tr[style=""]').length;
    const totalRows = document.querySelectorAll('#inventoryTableBody tr').length;
    console.log(`Showing ${visibleRows} of ${totalRows} products`);
}

/**
 * Update inventory statistics displayed at the top of the page
 */
function updateInventoryStats() {
    // Get all products
    const rows = document.querySelectorAll('#inventoryTableBody tr');
    
    let inStockCount = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;
    
    rows.forEach(row => {
        const stockStatus = row.cells[4].textContent.trim();
        
        if (stockStatus === 'In Stock') {
            inStockCount++;
        } else if (stockStatus === 'Low Stock') {
            lowStockCount++;
        } else if (stockStatus === 'Out of Stock') {
            outOfStockCount++;
        }
    });
    
    // Update the stats in the UI
    document.getElementById('inStockCount').textContent = inStockCount;
    document.getElementById('lowStockCount').textContent = lowStockCount;
    document.getElementById('outOfStockCount').textContent = outOfStockCount;
    
    // For demo purposes, show a random number of updates today
    const updatesToday = Math.floor(Math.random() * 10) + 1;
    document.getElementById('stockUpdatesToday').textContent = updatesToday;
}

/**
 * Open the stock update modal for a specific product
 */
function openStockUpdateModal(productId, productName, currentStock) {
    const modal = document.getElementById('stockUpdateModal');
    
    document.getElementById('updateProductId').value = productId;
    document.getElementById('productName').value = productName;
    document.getElementById('currentStock').value = currentStock;
    document.getElementById('stockChange').value = 1;
    document.getElementById('stockNotes').value = '';
    
    modal.style.display = 'block';
}

/**
 * Update a product's stock based on form input
 */
function updateProductStock() {
    const productId = document.getElementById('updateProductId').value;
    const productName = document.getElementById('productName').value;
    const changeType = document.getElementById('stockChangeType').value;
    const changeAmount = parseInt(document.getElementById('stockChange').value);
    const notes = document.getElementById('stockNotes').value;
    const currentStock = parseInt(document.getElementById('currentStock').value);
    
    // Calculate new stock level
    let newStock = currentStock;
    
    if (changeType === 'add') {
        newStock = currentStock + changeAmount;
    } else if (changeType === 'remove') {
        newStock = Math.max(0, currentStock - changeAmount);
    } else if (changeType === 'set') {
        newStock = Math.max(0, changeAmount);
    }
    
    // In a real application, this would update the database
    // For demo purposes, we'll create a log entry
    console.log(`Stock update for ${productName} (${productId}):`);
    console.log(`Changed from ${currentStock} to ${newStock} (${changeType} ${changeAmount})`);
    console.log(`Notes: ${notes}`);
    console.log(`Timestamp: ${new Date().toLocaleString()}`);
    
    // Add to stock history (in a real app, this would be stored in the database)
    addToStockHistory(productId, productName, currentStock, newStock, changeType, changeAmount, notes);
    
    // Refresh the inventory data
    loadInventoryData();
    updateInventoryStats();
    
    // Show a success notification
    const notification = document.createElement('div');
    notification.className = 'notification success';
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        Stock updated successfully for ${productName}
    `;
    document.body.appendChild(notification);
    
    // Remove the notification after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

/**
 * Store stock update history (simulated for demo purposes)
 */
let stockHistoryData = {};

function addToStockHistory(productId, productName, oldStock, newStock, changeType, changeAmount, notes) {
    if (!stockHistoryData[productId]) {
        stockHistoryData[productId] = [];
    }
    
    stockHistoryData[productId].push({
        timestamp: new Date().toLocaleString(),
        oldStock: oldStock,
        newStock: newStock,
        changeType: changeType,
        changeAmount: changeAmount,
        notes: notes
    });
}

/**
 * View stock history for a specific product
 */
function viewStockHistory(productId) {
    // Get product details
    const product = furnitureDB.getProductById(productId);
    
    if (!product) {
        alert('Product not found');
        return;
    }
    
    // Check if we have any history for this product
    if (!stockHistoryData[productId] || stockHistoryData[productId].length === 0) {
        alert(`No stock history available for ${product.name}`);
        return;
    }
    
    // In a real application, this would display a modal with the history
    // For demo purposes, we'll display an alert with the most recent updates
    const history = stockHistoryData[productId];
    let message = `Stock History for ${product.name} (${productId}):\n\n`;
    
    // Show up to the 5 most recent updates
    const recentHistory = history.slice(-5).reverse();
    
    recentHistory.forEach((entry, index) => {
        message += `${index + 1}. ${entry.timestamp}\n`;
        message += `   Changed from ${entry.oldStock} to ${entry.newStock} `;
        message += `(${entry.changeType} ${entry.changeAmount})\n`;
        if (entry.notes) {
            message += `   Notes: ${entry.notes}\n`;
        }
        message += '\n';
    });
    
    if (history.length > 5) {
        message += `... and ${history.length - 5} more updates`;
    }
    
    alert(message);
}

/**
 * Utility function to capitalize the first letter of a string
 */
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
} 