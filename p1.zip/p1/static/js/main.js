// Sample product data
const products = [
    {
        id: 1,
        name: "Modern Sofa",
        description: "Comfortable 3-seater sofa with premium fabric",
        price: 999.99,
        image: "https://example.com/sofa.jpg"
    },
    {
        id: 2,
        name: "Dining Table",
        description: "Solid wood dining table for 6 people",
        price: 599.99,
        image: "https://example.com/table.jpg"
    }
];

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', async function() {
    // Initialize mobile navigation
    initMobileNav();
    
    try {
        // Load featured products
        await loadFeaturedProducts();
        
        // Load new arrivals
        await loadNewArrivals();
        
        // Load category counters
        await updateCategoryCounters();
    } catch (error) {
        console.error('Error initializing page:', error);
    }
    
    // Setup search functionality
    setupSearch();
    
    // Initialize animations
    initAnimations();
});

// Initialize mobile navigation
function initMobileNav() {
    const mobileToggle = document.getElementById('mobileToggle');
    const mainNav = document.getElementById('mainNav');
    
    if (mobileToggle && mainNav) {
        mobileToggle.addEventListener('click', () => {
            mainNav.classList.toggle('active');
        });
    }
}

// Load featured products
async function loadFeaturedProducts() {
    const featuredContainer = document.getElementById('featured-products');
    if (!featuredContainer) return;
    
    try {
        // Get featured products from API
        const featuredProducts = await API.getFeaturedProducts();
        
        // Display featured products (limit to 4)
        featuredProducts.slice(0, 4).forEach(product => {
            const productCard = createProductCard(product);
            featuredContainer.appendChild(productCard);
        });
    } catch (error) {
        console.error('Error loading featured products:', error);
        // Fallback to localStorage data if API fails
        const featuredProducts = furnitureDB.getFeaturedProducts().slice(0, 4);
        featuredProducts.forEach(product => {
            const productCard = createProductCard(product);
            featuredContainer.appendChild(productCard);
        });
    }
}

// Load new arrivals
async function loadNewArrivals() {
    const newArrivalsContainer = document.getElementById('new-arrivals');
    if (!newArrivalsContainer) return;
    
    try {
        // Get new arrivals from API
        const newProducts = await API.getNewArrivals();
        
        // Display new arrivals (limit to 4)
        newProducts.slice(0, 4).forEach(product => {
            const productCard = createProductCard(product);
            newArrivalsContainer.appendChild(productCard);
        });
    } catch (error) {
        console.error('Error loading new arrivals:', error);
        // Fallback to localStorage data if API fails
        const newProducts = furnitureDB.getNewArrivals().slice(0, 4);
        newProducts.forEach(product => {
            const productCard = createProductCard(product);
            newArrivalsContainer.appendChild(productCard);
        });
    }
}

// Create product card
function createProductCard(product) {
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    
    // Get category name
    let categoryName = '';
    switch(product.category) {
        case 'chairs': categoryName = 'Chairs'; break;
        case 'sofas': categoryName = 'Sofas'; break;
        case 'tables': categoryName = 'Tables'; break;
        case 'lighting': categoryName = 'Lighting'; break;
        case 'accessories': categoryName = 'Accessories'; break;
        case 'bade': categoryName = 'Beds'; break;
        default: categoryName = capitalizeFirstLetter(product.category);
    }
    
    // Build card HTML
    productCard.innerHTML = `
        <div class="product-image">
            <img src="${product.image}" alt="${product.name}">
            <div class="product-quick-actions">
                <button class="action-btn" title="Add to Wishlist">
                    <i class="fas fa-heart"></i>
                </button>
                <button class="action-btn" title="Quick View">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="action-btn" title="Add to Cart">
                    <i class="fas fa-shopping-cart"></i>
                </button>
            </div>
            ${product.new ? '<span style="position: absolute; top: 10px; left: 10px; background: var(--accent-color2); color: white; padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.7rem; font-weight: 500;">NEW</span>' : ''}
        </div>
        <div class="product-info">
            <span class="category-tag ${getCategoryClass(product.category)}">${categoryName}</span>
            <h3>${product.name}</h3>
            <p>${product.description ? (product.description.split('.')[0] + '.') : ''}</p>
            <div style="display: flex; margin-top: 0.5rem; margin-bottom: 1rem;">
                <div style="display: flex; align-items: center;">
                    ${displayRating(product.rating)}
                    <span style="margin-left: 0.5rem; font-size: 0.8rem; opacity: 0.7;">(${product.reviewCount || 0})</span>
                </div>
            </div>
            <div class="product-footer">
                <div>
                    <div class="product-rating">
                        ${displayRating(product.rating)}
                        <span style="margin-left: 0.5rem; font-size: 0.8rem; opacity: 0.7;">(${product.reviewCount || 0})</span>
                    </div>
                    <span class="product-price">ETB ${parseFloat(product.price).toFixed(2)}</span>
                </div>
                <a href="product.html?id=${product.id}" class="btn btn-primary">Details</a>
            </div>
        </div>
    `;
    
    // Add event listeners for quick action buttons
    const quickActionBtns = productCard.querySelectorAll('.action-btn');
    
    quickActionBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const action = this.getAttribute('title');
            
            // Simulate action (in real app, these would do something)
            alert(`${action} for ${product.name}`);
        });
    });
    
    return productCard;
}

// Get CSS class for category tag
function getCategoryClass(category) {
    switch(category) {
        case 'chairs': return 'bg-chairs';
        case 'sofas': return 'bg-sofas';
        case 'tables': return 'bg-tables';
        case 'lighting': return 'bg-lighting';
        case 'accessories': return 'bg-accessories';
        default: return 'bg-chairs';
    }
}

// Display star rating
function displayRating(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    
    let starsHTML = '';
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star" style="color: var(--accent-color); font-size: 0.8rem;"></i>';
    }
    
    // Add half star if needed
    if (hasHalfStar) {
        starsHTML += '<i class="fas fa-star-half-alt" style="color: var(--accent-color); font-size: 0.8rem;"></i>';
    }
    
    // Add empty stars
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += '<i class="far fa-star" style="color: var(--accent-color); font-size: 0.8rem;"></i>';
    }
    
    return starsHTML;
}

// Update category counters
async function updateCategoryCounters() {
    try {
        // Get categories from API
        const categories = await API.getCategories();
        
        // Update category counters in the footer
        Object.keys(categories).forEach(categoryId => {
            const countBadge = document.querySelector(`.count-badge[data-category="${categoryId}"]`);
            if (countBadge) {
                countBadge.textContent = categories[categoryId].count;
            }
        });
    } catch (error) {
        console.error('Error updating category counters:', error);
        // Fallback to localStorage data if API fails
        const categories = furnitureDB.getCategories();
        Object.keys(categories).forEach(categoryId => {
            const countBadge = document.querySelector(`.count-badge[data-category="${categoryId}"]`);
            if (countBadge) {
                countBadge.textContent = categories[categoryId].count;
            }
        });
    }
}

// Setup search functionality
function setupSearch() {
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    
    if (searchForm && searchInput) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchTerm = searchInput.value.trim();
            
            if (searchTerm) {
                window.location.href = `products.html?search=${encodeURIComponent(searchTerm)}`;
            }
        });
    }
}

// Initialize animations
function initAnimations() {
    // Animation for hero section
    const heroSection = document.querySelector('.hero');
    if (heroSection) {
        heroSection.classList.add('animate');
    }
    
    // Reveal animations for sections
    window.addEventListener('scroll', revealSections);
    revealSections(); // Call once on load
}

// Reveal sections as user scrolls
function revealSections() {
    const sections = document.querySelectorAll('.section');
    
    sections.forEach(section => {
        const sectionTop = section.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (sectionTop < windowHeight * 0.8) {
            section.classList.add('reveal');
        }
    });
}

// Utility function to capitalize first letter
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Function to display products
function displayProducts() {
    const productGrid = document.getElementById('productGrid');
    
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        
        productCard.innerHTML = `
            <img src="${product.image}" alt="${product.name}" onerror="this.src='static/images/placeholder.jpg'">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p class="price">$${product.price}</p>
            <button onclick="viewProduct(${product.id})">View Details</button>
        `;
        
        productGrid.appendChild(productCard);
    });
}

// Function to view product details
function viewProduct(id) {
    const product = products.find(p => p.id === id);
    if (product) {
        alert(`Product Details:\nName: ${product.name}\nPrice: $${product.price}\nDescription: ${product.description}`);
    }
}

// Load products when page loads
window.addEventListener('load', displayProducts);