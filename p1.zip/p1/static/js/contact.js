// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize mobile navigation
    initMobileNav();
    
    // Initialize contact form
    initContactForm();
    
    // Load company information
    loadCompanyInfo();
    
    // Update category counters in footer
    updateCategoryCounters();
});

// Initialize mobile navigation
function initMobileNav() {
    const mobileToggle = document.getElementById('mobileToggle');
    const mainNav = document.getElementById('mainNav');
    
    if (mobileToggle && mainNav) {
        mobileToggle.addEventListener('click', () => {
            mainNav.classList.toggle('active');
        });
    }
}

// Initialize contact form
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();
            
            // Validate form
            if (!validateForm(name, email, subject, message)) {
                return;
            }
            
            // In a real app, you would send the form data to a server here
            // For this demo, we'll just show a success message
            alert('Your message has been sent successfully!');
            
            // Reset form
            contactForm.reset();
        });
    }
}

// Load company information from database
function loadCompanyInfo() {
    // Check if furnitureDB is available
    if (typeof furnitureDB === 'undefined' || !furnitureDB.companyInfo) {
        console.error('Company information not available');
        return;
    }
    
    const companyInfo = furnitureDB.companyInfo;
    
    // Update contact information
    updateContactInfo('company-name', companyInfo.name);
    updateContactInfo('company-email', companyInfo.email);
    updateContactInfo('company-phone', companyInfo.phone);
    updateContactInfo('company-address', companyInfo.address);
    
    // Update company description
    updateContactInfo('company-description', companyInfo.description);
    
    // Update year founded
    updateContactInfo('year-founded', companyInfo.yearFounded);
}

// Update contact information helper
function updateContactInfo(elementId, value) {
    const element = document.getElementById(elementId);
    if (element && value) {
        element.textContent = value;
    }
}

// Update category counters
function updateCategoryCounters() {
    // Check if furnitureDB is available
    if (typeof furnitureDB === 'undefined' || !furnitureDB.getCategories) {
        console.error('Category information not available');
        return;
    }
    
    const categories = furnitureDB.getCategories();
    
    // Update category counters in the footer
    Object.keys(categories).forEach(categoryId => {
        const countBadge = document.querySelector(`.count-badge[data-category="${categoryId}"]`);
        if (countBadge) {
            countBadge.textContent = categories[categoryId].count;
        }
    });
}

// Validate form
function validateForm(name, email, subject, message) {
    // Check for empty fields
    if (!name || !email || !subject || !message) {
        alert('Please fill in all fields');
        return false;
    }
    
    // Validate email format
    if (!validateEmail(email)) {
        alert('Please enter a valid email address');
        return false;
    }
    
    return true;
}

// Validate email format using regex
function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
} 