// JavaScript for the home page

document.addEventListener('DOMContentLoaded', async function() {
    // Initialize mobile navigation
    initMobileNav();
    
    // Load featured products
    await loadFeaturedProducts();
    
    // Apply animations
    initAnimations();
});

// Initialize mobile navigation
function initMobileNav() {
    const mobileToggle = document.getElementById('mobileToggle');
    const mainNav = document.getElementById('mainNav');
    
    if (mobileToggle && mainNav) {
        mobileToggle.addEventListener('click', () => {
            mainNav.classList.toggle('active');
            mobileToggle.classList.toggle('active');
        });
    }
}

// Load featured products
async function loadFeaturedProducts() {
    try {
        const featuredContainer = document.getElementById('featured-products');
        if (!featuredContainer) return;
        
        // Try to load from MongoDB API first, fall back to local data
        let featuredProducts;
        
        if (typeof mongoDBClient !== 'undefined') {
            featuredProducts = await mongoDBClient.getFeaturedProducts();
        } else {
            featuredProducts = furnitureDB.getFeaturedProducts();
        }
        
        // Limit to 6 featured products for the homepage
        const limitedProducts = featuredProducts.slice(0, 6);
        
        if (limitedProducts.length === 0) {
            featuredContainer.innerHTML = '<p class="text-center">No featured products available at the moment.</p>';
            return;
        }
        
        // Generate HTML for each product
        let productsHTML = '';
        
        limitedProducts.forEach(product => {
            const categoryClass = getCategoryClass(product.category);
            
            productsHTML += `
                <div class="product-card reveal-animation">
                    <div class="product-image">
                        <img src="${product.image}" alt="${product.name}" loading="lazy">
                        <div class="product-quick-actions">
                            <button class="action-btn" title="Quick View">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn" title="Add to Wishlist">
                                <i class="fas fa-heart"></i>
                            </button>
                        </div>
                    </div>
                    <div class="product-info">
                        <span class="category-tag ${categoryClass}">${getCategoryName(product.category)}</span>
                        <h3>${product.name}</h3>
                        <p>${limitText(product.description, 100)}</p>
                        <div class="product-meta">
                            <span class="product-price">$${product.price.toFixed(2)}</span>
                            <a href="product.html?id=${product.id}" class="btn btn-primary btn-sm">View Details</a>
                        </div>
                    </div>
                </div>
            `;
        });
        
        featuredContainer.innerHTML = productsHTML;
    } catch (error) {
        console.error('Error loading featured products:', error);
    }
}

// Initialize animations
function initAnimations() {
    const revealAnimations = document.querySelectorAll('.reveal-animation');
    
    const revealCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    };
    
    const revealObserver = new IntersectionObserver(revealCallback, {
        threshold: 0.1
    });
    
    revealAnimations.forEach(animation => {
        revealObserver.observe(animation);
    });
}

// Helper function to get CSS class for category tag
function getCategoryClass(category) {
    switch(category) {
        case 'chairs': return 'bg-chairs';
        case 'sofas': return 'bg-sofas';
        case 'tables': return 'bg-tables';
        case 'lighting': return 'bg-lighting';
        case 'accessories': return 'bg-accessories';
        case 'bade': return 'bg-bade';
        default: return 'bg-chairs';
    }
}

// Helper function to get category display name
function getCategoryName(categoryId) {
    const categories = furnitureDB.getCategories();
    return categories[categoryId] ? categories[categoryId].name : categoryId;
}

// Helper function to limit text length
function limitText(text, limit) {
    if (text.length <= limit) return text;
    return text.substring(0, limit) + '...';
}
