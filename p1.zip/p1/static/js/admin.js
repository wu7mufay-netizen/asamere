document.addEventListener('DOMContentLoaded', async function() {
    console.log('Admin interface initializing...');
    
    // Initialize tabs
    initTabs();
    
    // Load product table
    if (document.getElementById('productTableBody')) {
        await loadProductTable();
    }
    
    // Set up product form
    if (document.getElementById('productForm')) {
        setupProductForm();
    }
    
    // Set up product search
    if (document.getElementById('productSearch')) {
        setupProductSearch();
    }
    
    // Set up product filter
    if (document.getElementById('categoryFilter')) {
        setupProductFilter();
    }
    
    // Set up categories management
    if (document.getElementById('categoriesList')) {
        await loadCategories();
    }
    
    // Set up event listeners for dashboard
    setupDashboardEvents();
});

// Initialize tab system
function initTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            
            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button and corresponding content
            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
            
            // Store active tab in sessionStorage
            sessionStorage.setItem('activeAdminTab', tabId);
        });
    });
    
    // Check if there's a stored active tab
    const activeTab = sessionStorage.getItem('activeAdminTab');
    if (activeTab) {
        const activeButton = document.querySelector(`.tab-btn[data-tab="${activeTab}"]`);
        if (activeButton) {
            activeButton.click();
        }
    }
}

// Helper function to create a category-specific placeholder image
function createCategoryPlaceholder(category, productName) {
    // Colors for different categories
    const colors = {
        sofas: '#f43f5e',      // Pink
        tables: '#10b981',     // Green
        chairs: '#3b82f6',     // Blue
        beds: '#8b5cf6',       // Purple
        bade: '#8b5cf6',       // Purple (keeping for backward compatibility)
        default: '#6b7280'     // Gray
    };
    
    // Get color based on category
    const bgColor = colors[category] || colors.default;
    const textColor = '#ffffff';
    
    // Get first letter of product name or use a default icon
    const displayText = productName && productName.length > 0 ? 
        productName.charAt(0).toUpperCase() : 
        category.charAt(0).toUpperCase();
    
    // Generate SVG
    const svg = `
    <svg width="300" height="300" xmlns="http://www.w3.org/2000/svg">
        <rect width="300" height="300" fill="${bgColor}" />
        <text fill="${textColor}" font-family="Arial" font-size="100" font-weight="bold" text-anchor="middle" x="150" y="180">${displayText}</text>
    </svg>`;
    
    // Convert to data URI
    return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
}

// Helper function to fix category references in path construction
function getImageCategoryPath(category) {
    // Map 'bade' to 'beds' for image paths
    if (category === 'bade') {
        return 'beds';
    }
    return category;
}

// Load product table with data from API
async function loadProductTable() {
    const tableBody = document.getElementById('productTableBody');
    if (!tableBody) return;
    
    try {
        // Show loading indicator
        tableBody.innerHTML = '<tr><td colspan="9" style="text-align: center;">Loading products...</td></tr>';
        
        // Get filter values
        const categoryFilter = document.getElementById('categoryFilter')?.value || '';
        const stockFilter = document.getElementById('stockFilter')?.value || '';
        
        // Get products from API
        let products = await API.getAllProducts();
        
        // Apply filters if necessary
        if (categoryFilter) {
            products = products.filter(product => product.category === categoryFilter);
        }
        
        if (stockFilter) {
            const inStock = stockFilter === 'instock';
            products = products.filter(product => product.inStock === inStock);
        }
        
        if (products.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="9" style="text-align: center;">No products found</td></tr>';
            return;
        }
        
        // Generate table rows
        tableBody.innerHTML = '';
        products.forEach(product => {
            const row = document.createElement('tr');
            
            // Fix image path
            let imagePath = product.image;
            
            // If there's no image or it's an invalid path, create a placeholder
            if (!imagePath || imagePath === "" || imagePath === "undefined") {
                imagePath = createCategoryPlaceholder(product.category, product.name);
            } 
            // If it's a server path but doesn't start with /
            else if (imagePath.includes('image/') && !imagePath.startsWith('/') && !imagePath.startsWith('data:')) {
                imagePath = '/' + imagePath;
            }
            // If it's just a filename with an extension, construct the full path
            else if (!imagePath.includes('/') && !imagePath.startsWith('data:') && imagePath.includes('.')) {
                const categoryPath = getImageCategoryPath(product.category);
                imagePath = `/image/${categoryPath}/${imagePath}`;
            }
            // Ensure there are no spaces in the URL
            if (imagePath.includes(' ') && !imagePath.startsWith('data:')) {
                imagePath = imagePath.replace(/ /g, '%20');
            }
            
            // Format the product data for display
            const truncatedId = product.id.length > 8 ? product.id.substring(0, 8) + '...' : product.id;
            const imageThumb = `
                <div style="position: relative; width: 50px; height: 50px; border-radius: 5px; overflow: hidden;">
                    <img src="${imagePath}" 
                         alt="${product.name}" 
                         style="width: 100%; height: 100%; object-fit: cover;"
                         onerror="this.onerror=null; this.src='${createCategoryPlaceholder(product.category, product.name)}'">
                </div>
            `;
            
            row.innerHTML = `
                <td>
                    <input type="checkbox" class="product-checkbox" data-id="${product.id}">
                </td>
                <td title="${product.id}">${truncatedId}</td>
                <td>${imageThumb}</td>
                <td>${product.name}</td>
                <td>${getCategoryName(product.category)}</td>
                <td>ETB ${parseFloat(product.price).toFixed(2)}</td>
                <td>
                    <span class="product-status" style="background: ${product.inStock ? 'rgba(16, 185, 129, 0.1); color: #10b981;' : 'rgba(239, 68, 68, 0.1); color: #ef4444;'}">
                        ${product.inStock ? 'In Stock' : 'Out of Stock'}
                    </span>
                </td>
                <td>
                    ${product.featured ? '<i class="fas fa-star" style="color: var(--accent-color);"></i>' : '<i class="far fa-star" style="color: rgba(255,255,255,0.5);"></i>'}
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn edit-product" data-id="${product.id}" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn view-product" data-id="${product.id}" title="View">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn delete-product" data-id="${product.id}" title="Delete">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </td>
            `;
            
            tableBody.appendChild(row);
        });
        
        // Add event listeners to action buttons
        document.querySelectorAll('.edit-product').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.dataset.id;
                editProduct(productId);
            });
        });
        
        document.querySelectorAll('.view-product').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.dataset.id;
                window.open(`product.html?id=${productId}`, '_blank');
            });
        });
        
        document.querySelectorAll('.delete-product').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.dataset.id;
                if (confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
                    deleteProduct(productId);
                }
            });
        });
        
        // Set up "Select All" checkbox
        const selectAll = document.getElementById('selectAll');
        if (selectAll) {
            selectAll.addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('.product-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = selectAll.checked;
                });
            });
        }
        
    } catch (error) {
        console.error('Error loading product table:', error);
        tableBody.innerHTML = `<tr><td colspan="9" style="text-align: center; color: #ef4444;">Error loading products: ${error.message}</td></tr>`;
    }
}

// Helper function to get category name from ID
function getCategoryName(categoryId) {
    const categoryMap = {
        'chairs': 'Chairs',
        'sofas': 'Sofas',
        'tables': 'Tables',
        'lighting': 'Lighting',
        'accessories': 'Accessories',
        'beds': 'Beds',
        'bade': 'Beds'  // Map 'bade' to 'Beds' for backward compatibility
    };
    
    return categoryMap[categoryId] || categoryId;
}

// Load a product into the edit form
async function editProduct(productId) {
    try {
        // Switch to the edit tab
        const addProductTab = document.querySelector('.tab-btn[data-tab="add-product"]');
        if (addProductTab) {
            addProductTab.click();
        }
        
        // Show loading state
        document.getElementById('productForm').classList.add('loading');
        
        // Get product data
        const product = await API.getProductById(productId);
        
        // Fix category if it's 'bade'
        if (product.category === 'bade') {
            console.log('Converting legacy category "bade" to "beds"');
            product.category = 'beds';
        }
        
        // Populate form fields
        document.getElementById('productName').value = product.name;
        document.getElementById('productCategory').value = product.category;
        document.getElementById('productDescription').value = product.description;
        document.getElementById('productPrice').value = product.price;
        
        // Handle image path
        let imagePath = product.image;
        
        // If there's no image or it's an invalid path, create a placeholder
        if (!imagePath || imagePath === "" || imagePath === "undefined") {
            imagePath = createCategoryPlaceholder(product.category, product.name);
        } 
        // If it's a server path but doesn't start with /
        else if (imagePath.includes('image/') && !imagePath.startsWith('/') && !imagePath.startsWith('data:')) {
            imagePath = '/' + imagePath;
        }
        // If it's just a filename with an extension, construct the full path
        else if (!imagePath.includes('/') && !imagePath.startsWith('data:') && imagePath.includes('.')) {
            const categoryPath = getImageCategoryPath(product.category);
            imagePath = `/image/${categoryPath}/${imagePath}`;
        }
        
        // Ensure there are no spaces in the URL
        if (imagePath.includes(' ') && !imagePath.startsWith('data:')) {
            imagePath = imagePath.replace(/ /g, '%20');
        }
        
        // Update image path in product object so it's saved correctly
        product.image = imagePath;
        
        // Handle image preview
        document.getElementById('productImage').value = '';  // Clear the input to avoid confusion
        document.getElementById('imagePreview').src = imagePath;
        document.getElementById('imagePreviewContainer').style.display = 'block';
        
        // Update image preview
        const imagePreviewLabel = document.querySelector('label[for="imagePreview"]');
        if (imagePreviewLabel) {
            imagePreviewLabel.textContent = 'Current Image';
        }
        
        // Handle checkboxes
        document.getElementById('productFeatured').checked = Boolean(product.featured);
        document.getElementById('productInStock').checked = Boolean(product.inStock);
        document.getElementById('productNew').checked = Boolean(product.new);
        
        // Handle additional fields if they exist
        if (product.specs) {
            const specs = typeof product.specs === 'string' ? JSON.parse(product.specs) : product.specs;
            
            if (document.getElementById('productDimensions')) {
                document.getElementById('productDimensions').value = specs.dimensions || '';
            }
            
            if (document.getElementById('productWeight')) {
                document.getElementById('productWeight').value = specs.weight || '';
            }
            
            if (document.getElementById('productMaterial')) {
                document.getElementById('productMaterial').value = specs.material || '';
            }
            
            if (document.getElementById('productColors')) {
                document.getElementById('productColors').value = specs.colors ? specs.colors.join(', ') : '';
            }
        }
        
        // Set the product ID in a hidden field
        document.getElementById('productId').value = productId;
        
        // Update submit button text
        document.getElementById('submitButton').textContent = 'Update Product';
        
        // Set form state to edit
        document.getElementById('productForm').dataset.mode = 'edit';
        
        // Remove loading state
        document.getElementById('productForm').classList.remove('loading');
        
    } catch (error) {
        console.error('Error loading product for edit:', error);
        alert('Error loading product: ' + error.message);
        document.getElementById('productForm').classList.remove('loading');
    }
}

// Delete a product
async function deleteProduct(productId) {
    try {
        await API.deleteProduct(productId);
        
        // Reload the product table
        await loadProductTable();
        
        // Update dashboard stats
        await updateDashboardStats();
        
        // Show success message
        alert('Product deleted successfully');
    } catch (error) {
        console.error('Error deleting product:', error);
        alert(`Error deleting product: ${error.message}`);
    }
}

// Setup product form
function setupProductForm() {
    const productForm = document.getElementById('productForm');
    if (!productForm) return;
    
    // Set up image preview
    const productImage = document.getElementById('productImage');
    const imagePreview = document.getElementById('imagePreview');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    
    if (productImage && imagePreview) {
        productImage.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreviewContainer.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Set up categories dropdown
    const categoryDropdown = document.getElementById('productCategory');
    if (categoryDropdown) {
        populateCategoryDropdown(categoryDropdown);
    }
    
    // Set up form submission
    productForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        try {
            // Show loading state
            productForm.classList.add('loading');
            
            // Get form data
            const formData = new FormData(productForm);
            const productData = {
                name: formData.get('name'),
                description: formData.get('description'),
                category: formData.get('category'),
                price: parseFloat(formData.get('price')),
                featured: formData.get('featured') === 'on',
                inStock: formData.get('inStock') === 'on',
                new: formData.get('new') === 'on'
            };
            
            // Add specs object if any spec fields exist
            const specFields = {
                dimensions: formData.get('dimensions'),
                weight: formData.get('weight'),
                material: formData.get('material')
            };
            
            // Parse colors into an array if a colors field exists
            if (formData.get('colors')) {
                specFields.colors = formData.get('colors')
                    .split(',')
                    .map(color => color.trim())
                    .filter(color => color);
            }
            
            // Only add specs if at least one spec field has a value
            if (Object.values(specFields).some(value => value)) {
                productData.specs = specFields;
            }
            
            // Handle image (file or URL)
            const imageFile = document.getElementById('productImage').files[0];
            
            if (imageFile) {
                // Upload image to server and get path
                const imagePath = await uploadImage(imageFile);
                if (imagePath) {
                    productData.image = imagePath;
                } else {
                    // If upload fails, use category placeholder
                    productData.image = createCategoryPlaceholder(productData.category, productData.name);
                }
            } else if (imagePreview && imagePreview.src && imagePreview.src.startsWith('data:')) {
                // Use existing data URI for image (placeholder or previous upload)
                productData.image = imagePreview.src;
            } else {
                // No image, generate placeholder
                productData.image = createCategoryPlaceholder(productData.category, productData.name);
            }
            
            // Check if we're editing or adding
            const isEdit = productForm.dataset.mode === 'edit';
            let result;
            
            if (isEdit) {
                // Get product ID from form
                const productId = document.getElementById('productId').value;
                
                // Update existing product
                result = await API.updateProduct(productId, productData);
                console.log('Product updated:', result);
                
                // Show success message
                showNotification('Product updated successfully');
            } else {
                // Create new product
                result = await API.createProduct(productData);
                console.log('Product created:', result);
                
                // Show success message
                showNotification('Product created successfully');
                
                // Reset form for next entry
                productForm.reset();
                imagePreviewContainer.style.display = 'none';
            }
            
            // Reload product table to show changes
            loadProductTable();
            
            // Update dashboard stats
            updateDashboardStats();
        } catch (error) {
            console.error('Error saving product:', error);
            showNotification('Error saving product: ' + error.message, 'error');
        } finally {
            // Remove loading state
            productForm.classList.remove('loading');
        }
    });
    
    // Reset button to clear form
    const resetButton = document.getElementById('resetButton');
    if (resetButton) {
        resetButton.addEventListener('click', function() {
            productForm.reset();
            imagePreviewContainer.style.display = 'none';
            
            // Reset form state
            productForm.dataset.mode = 'add';
            
            // Update submit button text
            document.getElementById('submitButton').textContent = 'Add Product';
            
            // Clear product ID
            document.getElementById('productId').value = '';
        });
    }
}

// Helper function to show notifications
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Add to document
    document.body.appendChild(notification);
    
    // Position it
    notification.style.position = 'fixed';
    notification.style.bottom = '20px';
    notification.style.right = '20px';
    notification.style.padding = '10px 15px';
    notification.style.borderRadius = '5px';
    notification.style.color = 'white';
    notification.style.backgroundColor = type === 'success' ? '#10b981' : '#ef4444';
    notification.style.boxShadow = '0 3px 10px rgba(0,0,0,0.2)';
    notification.style.zIndex = '9999';
    notification.style.opacity = '0';
    notification.style.transform = 'translateY(10px)';
    notification.style.transition = 'all 0.3s ease';
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateY(0)';
    }, 10);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(10px)';
        
        // Remove from DOM after animation
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Helper function to populate category dropdown
async function populateCategoryDropdown(dropdown) {
    try {
        // Get categories
        const categories = await API.getCategories();
        
        // Clear existing options (except the first one)
        while (dropdown.options.length > 1) {
            dropdown.remove(1);
        }
        
        // Add options for each category
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            dropdown.appendChild(option);
        });
    } catch (error) {
        console.error('Error populating category dropdown:', error);
    }
}

// Set up product search functionality
function setupProductSearch() {
    const searchInput = document.getElementById('productSearch');
    
    searchInput.addEventListener('input', debounce(async function() {
        const searchTerm = searchInput.value.trim().toLowerCase();
        
        if (!searchTerm) {
            await loadProductTable();
            return;
        }
        
        try {
            // Get all products and filter them client-side for faster response
            const products = await API.getAllProducts();
            
            const filteredProducts = products.filter(product => 
                product.name.toLowerCase().includes(searchTerm) ||
                product.description.toLowerCase().includes(searchTerm) ||
                product.id.toLowerCase().includes(searchTerm) ||
                getCategoryName(product.category).toLowerCase().includes(searchTerm)
            );
            
            // Update the table with filtered products
            displayFilteredProducts(filteredProducts);
            
        } catch (error) {
            console.error('Error searching products:', error);
        }
    }, 300));
}

// Display filtered products in the table
function displayFilteredProducts(products) {
    const tableBody = document.getElementById('productTableBody');
    if (!tableBody) return;
    
    if (products.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="9" style="text-align: center;">No products found</td></tr>';
        return;
    }
    
    // Clear existing rows
    tableBody.innerHTML = '';
    
    // Add filtered product rows
    products.forEach(product => {
        const row = document.createElement('tr');
        
        // Fix image path
        let imagePath = product.image;
        
        // If there's no image or it's an invalid path, create a placeholder
        if (!imagePath || imagePath === "" || imagePath === "undefined") {
            imagePath = createCategoryPlaceholder(product.category, product.name);
        } 
        // If it's a server path but doesn't start with /
        else if (imagePath.includes('image/') && !imagePath.startsWith('/') && !imagePath.startsWith('data:')) {
            imagePath = '/' + imagePath;
        }
        // If it's just a filename with an extension, construct the full path
        else if (!imagePath.includes('/') && !imagePath.startsWith('data:') && imagePath.includes('.')) {
            const categoryPath = getImageCategoryPath(product.category);
            imagePath = `/image/${categoryPath}/${imagePath}`;
        }
        
        // Ensure there are no spaces in the URL
        if (imagePath.includes(' ') && !imagePath.startsWith('data:')) {
            imagePath = imagePath.replace(/ /g, '%20');
        }
        
        // Format the product data for display
        const truncatedId = product.id.length > 8 ? product.id.substring(0, 8) + '...' : product.id;
        const imageThumb = `
            <div style="position: relative; width: 50px; height: 50px; border-radius: 5px; overflow: hidden;">
                <img src="${imagePath}" 
                     alt="${product.name}" 
                     style="width: 100%; height: 100%; object-fit: cover;"
                     onerror="this.onerror=null; this.src='${createCategoryPlaceholder(product.category, product.name)}'">
            </div>
        `;
        
        row.innerHTML = `
            <td>
                <input type="checkbox" class="product-checkbox" data-id="${product.id}">
            </td>
            <td title="${product.id}">${truncatedId}</td>
            <td>${imageThumb}</td>
            <td>${product.name}</td>
            <td>${getCategoryName(product.category)}</td>
            <td>ETB ${parseFloat(product.price).toFixed(2)}</td>
            <td>
                <span class="product-status" style="background: ${product.inStock ? 'rgba(16, 185, 129, 0.1); color: #10b981;' : 'rgba(239, 68, 68, 0.1); color: #ef4444;'}">
                    ${product.inStock ? 'In Stock' : 'Out of Stock'}
                </span>
            </td>
            <td>
                ${product.featured ? '<i class="fas fa-star" style="color: var(--accent-color);"></i>' : '<i class="far fa-star" style="color: rgba(255,255,255,0.5);"></i>'}
            </td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn edit-product" data-id="${product.id}" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn view-product" data-id="${product.id}" title="View">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn delete-product" data-id="${product.id}" title="Delete">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // Re-attach event listeners
    document.querySelectorAll('.edit-product').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.id;
            editProduct(productId);
        });
    });
    
    document.querySelectorAll('.view-product').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.id;
            window.open(`product.html?id=${productId}`, '_blank');
        });
    });
    
    document.querySelectorAll('.delete-product').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.id;
            if (confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
                deleteProduct(productId);
            }
        });
    });
}

// Set up product filter functionality
function setupProductFilter() {
    const categoryFilter = document.getElementById('categoryFilter');
    const stockFilter = document.getElementById('stockFilter');
    const filterButton = document.querySelector('.admin-content button.btn-secondary:last-of-type');
    
    if (filterButton) {
        filterButton.addEventListener('click', async function() {
            await loadProductTable();
        });
    }
    
    // Add change event listeners for immediate filtering if no filter button
    if (!filterButton) {
        if (categoryFilter) {
            categoryFilter.addEventListener('change', async function() {
                await loadProductTable();
            });
        }
        
        if (stockFilter) {
            stockFilter.addEventListener('change', async function() {
                await loadProductTable();
            });
        }
    }
}

// Load categories for management
async function loadCategories() {
    const categoriesList = document.getElementById('categoriesList');
    if (!categoriesList) return;
    
    try {
        // Show loading indicator
        categoriesList.innerHTML = '<p>Loading categories...</p>';
        
        // Get categories from API
        const categories = await API.getCategories();
        
        if (Object.keys(categories).length === 0) {
            categoriesList.innerHTML = '<p>No categories found</p>';
            return;
        }
        
        // Generate list items
        categoriesList.innerHTML = '';
        
        Object.values(categories).forEach(category => {
            const categoryItem = document.createElement('div');
            categoryItem.className = 'category-item';
            categoryItem.style.display = 'flex';
            categoryItem.style.alignItems = 'center';
            categoryItem.style.marginBottom = '1rem';
            categoryItem.style.padding = '1rem';
            categoryItem.style.background = 'rgba(255,255,255,0.05)';
            categoryItem.style.borderRadius = '5px';
            
            categoryItem.innerHTML = `
                <div style="flex: 1;">
                    <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                <strong>${category.name}</strong>
                        <span class="tag" style="margin-left: 0.5rem;">${category.count} products</span>
                    </div>
                    <div style="font-size: 0.8rem; opacity: 0.7;">ID: ${category.id}</div>
                </div>
                <div>
                    <button class="action-btn edit-category" data-id="${category.id}" title="Edit Category">
                        <i class="fas fa-edit"></i>
                    </button>
            </div>
        `;
            
            categoriesList.appendChild(categoryItem);
        });
        
        // Add event listeners to edit buttons
        document.querySelectorAll('.edit-category').forEach(button => {
            button.addEventListener('click', function() {
                const categoryId = this.dataset.id;
                alert(`Editing category ${categoryId} - Feature coming soon!`);
                // TODO: Implement category editing functionality
            });
        });
        
    } catch (error) {
        console.error('Error loading categories:', error);
        categoriesList.innerHTML = `<p style="color: #ef4444;">Error loading categories: ${error.message}</p>`;
    }
}

// Update dashboard statistics
async function updateDashboardStats() {
    try {
        // Get data from API
        const products = await API.getAllProducts();
        const categories = await API.getCategories();
        
        // Calculate statistics
        const totalProducts = products.length;
        const totalCategories = Object.keys(categories).length;
        const featuredProducts = products.filter(product => product.featured).length;
        const inStockProducts = products.filter(product => product.inStock).length;
        
        // Update stat cards
        const statCards = document.querySelectorAll('.stat-value');
        if (statCards.length >= 4) {
            statCards[0].textContent = totalProducts;
            statCards[1].textContent = totalCategories;
            statCards[2].textContent = featuredProducts;
            statCards[3].textContent = inStockProducts;
        }
        
    } catch (error) {
        console.error('Error updating dashboard stats:', error);
    }
}

// Set up dashboard events
function setupDashboardEvents() {
    // Update stats when dashboard loads
    if (document.querySelector('.dashboard-stats')) {
        updateDashboardStats();
    }
}

// Function to generate a product using an image from the image folder
async function addProductWithServerImage(productData, imagePath) {
    try {
        // Generate a unique ID
        const timestamp = new Date().getTime();
        const randomStr = Math.random().toString(36).substring(2, 8);
        const productId = `p${timestamp}-${randomStr}`;
        
        // Fix category if it's 'bade'
        if (productData.category === 'bade') {
            console.log('Converting legacy category "bade" to "beds"');
            productData.category = 'beds';
        }
        
        // Ensure proper image path formatting
        let processedImagePath = imagePath;
        
        // If the image path contains a reference to 'bade', replace it with 'beds'
        if (processedImagePath.includes('/bade/') || processedImagePath.includes('\\bade\\')) {
            processedImagePath = processedImagePath.replace('/bade/', '/beds/').replace('\\bade\\', '\\beds\\');
        }
        
        // If the path includes 'image/' but doesn't start with a slash, add it
        if (processedImagePath.includes('image/') && !processedImagePath.startsWith('/') && !processedImagePath.startsWith('data:')) {
            processedImagePath = '/' + processedImagePath;
        }
        
        // Ensure there are no spaces in the URL
        if (processedImagePath.includes(' ') && !processedImagePath.startsWith('data:')) {
            processedImagePath = processedImagePath.replace(/ /g, '%20');
        }
        
        // Create product object
        const newProduct = {
            id: productId,
            name: productData.name,
            category: productData.category,
            description: productData.description,
            price: parseFloat(productData.price),
            image: processedImagePath,
            featured: productData.featured || false,
            inStock: productData.inStock || true,
            new: productData.new || true,
            rating: productData.rating || 4.5,
            reviewCount: productData.reviewCount || 0
        };
        
        // Add specs if available
        if (productData.specs) {
            newProduct.specs = productData.specs;
        }
        
        // Save to API
        await API.createProduct(newProduct);
        
        // Reload product table and update stats
        await loadProductTable();
        await updateDashboardStats();
        
        return newProduct;
    } catch (error) {
        console.error('Error adding product with server image:', error);
        throw error;
    }
}

// Debounce function to limit how often a function is called
function debounce(func, delay) {
    let timeout;
    return function() {
        const context = this;
        const args = arguments;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), delay);
    };
}

// Helper function to upload image files
async function uploadImage(file) {
    // In this case, we'll just convert to a Data URL since we don't have a server endpoint
    // In a real application, you would upload to a server
    try {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                resolve(e.target.result);
            };
            
            reader.onerror = function(e) {
                reject(new Error('Failed to read file'));
            };
            
            reader.readAsDataURL(file);
        });
    } catch (error) {
        console.error('Error uploading image:', error);
        return null;
    }
} 