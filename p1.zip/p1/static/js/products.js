/**
 * Products Page JavaScript
 * Handles loading, filtering, and displaying products from MySQL database
 */

// Core variables
let allProducts = [];
let currentProducts = [];
let currentCategory = null;
let currentSort = 'newest';

// DOM Elements
const productsGrid = document.getElementById('products-grid');
const loadingContainer = document.getElementById('loading-container');
const emptyState = document.getElementById('empty-state');
const productCountElement = document.getElementById('product-count');

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Products page initialized');
    
    // Initialize the page
    initMobileNav();
    initFilterButtons();
    initSortDropdown();
    initCategorySelect();  // Initialize the category select dropdown
    
    // Get parameters from URL
    const urlParams = new URLSearchParams(window.location.search);
    currentCategory = urlParams.get('category') || null;
    currentSort = urlParams.get('sort') || 'newest';
    
    // Log current category for debugging
    console.log('Current category from URL:', currentCategory);
    
    // Set the sort dropdown to match URL parameter
    const sortDropdown = document.getElementById('sort');
    if (sortDropdown && currentSort) {
        sortDropdown.value = currentSort;
    }
    
    // Set active category button
    setActiveCategory();
    
    // Load products
    try {
        await loadProducts();
    } catch (error) {
        console.error('Failed to load products:', error);
        showError('Failed to load products. Please try refreshing the page.');
    }
});

/**
 * Initialize mobile navigation
 */
function initMobileNav() {
    const mobileToggle = document.getElementById('mobileToggle');
    const mainNav = document.getElementById('mainNav');
    
    if (mobileToggle && mainNav) {
        mobileToggle.addEventListener('click', () => {
            mainNav.classList.toggle('active');
            mobileToggle.classList.toggle('active');
        });
    }
}

/**
 * Initialize filter category buttons
 */
function initFilterButtons() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.id.replace('filter-', '');
            
            if (category === 'all') {
                window.location.href = `products.html${currentSort !== 'newest' ? `?sort=${currentSort}` : ''}`;
            } else {
                // Special case for beds - use 'bade' as the actual category ID since that's what the backend uses
                const categoryParam = category === 'beds' ? 'bade' : category;
                window.location.href = `products.html?category=${categoryParam}${currentSort !== 'newest' ? `&sort=${currentSort}` : ''}`;
            }
        });
    });
}

/**
 * Initialize sort dropdown
 */
function initSortDropdown() {
    const sortDropdown = document.getElementById('sort');
    
    if (sortDropdown) {
        sortDropdown.addEventListener('change', () => {
            const newSort = sortDropdown.value;
            
            // Update URL with new sort parameter
            let url = 'products.html';
            if (currentCategory) {
                url += `?category=${currentCategory}`;
                if (newSort !== 'newest') {
                    url += `&sort=${newSort}`;
                }
            } else if (newSort !== 'newest') {
                url += `?sort=${newSort}`;
            }
            
            window.location.href = url;
        });
    }
}

/**
 * Set active category filter button and dropdown
 */
function setActiveCategory() {
    // Remove active class from all filters
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Get category dropdown
    const categorySelect = document.getElementById('categorySelect');
    
    // Add active class to current filter
    if (!currentCategory) {
        const allBtn = document.getElementById('filter-all');
        if (allBtn) {
            allBtn.classList.add('active');
        }
        
        // Set dropdown to empty (no selection)
        if (categorySelect) {
            categorySelect.value = '';
        }
    } else {
        // Map 'bade' to 'beds' for button selection
        const categoryForButton = currentCategory === 'bade' ? 'beds' : currentCategory;
        const filterBtn = document.getElementById(`filter-${categoryForButton}`);
        if (filterBtn) {
            filterBtn.classList.add('active');
        } else {
            // Fallback to 'all' if button doesn't exist
            const allBtn = document.getElementById('filter-all');
            if (allBtn) {
                allBtn.classList.add('active');
            }
        }
        
        // Set the dropdown to match the current category
        if (categorySelect) {
            categorySelect.value = currentCategory;
        }
    }
}

/**
 * Load products from API
 */
async function loadProducts() {
    try {
        showLoading(true);
        
        console.log(`Loading products with category: ${currentCategory || 'all'}, sort: ${currentSort}`);
        
        // Fetch products from API
        try {
            if (currentCategory) {
                currentProducts = await API.getProductsByCategory(currentCategory);
            } else {
                currentProducts = await API.getAllProducts();
            }
            
            // Keep a copy of all products
            allProducts = [...currentProducts];
            
            console.log(`Loaded ${currentProducts.length} products`);
        } catch (apiError) {
            console.error('API error:', apiError);
            // Fallback to local data in case of API error
            console.log('Falling back to local data');
            currentProducts = currentCategory 
                ? furnitureDB.getProductsByCategory(currentCategory)
                : furnitureDB.getAllProducts();
        }
        
        // Debug first product image path
        if (currentProducts && currentProducts.length > 0) {
            console.log("First product data:", currentProducts[0]);
            console.log("First product image path:", currentProducts[0].image);
        }
        
        // Sort products
        sortProducts(currentSort);
        
        // Update product count
        updateProductCount();
        
        // Display products
        displayProducts();
    } catch (error) {
        console.error('Error loading products:', error);
        showError('Failed to load products. Please try again later.');
    } finally {
        showLoading(false);
    }
}

/**
 * Sort products array based on sort criteria
 */
function sortProducts(sortBy) {
    if (!currentProducts || !Array.isArray(currentProducts) || currentProducts.length === 0) {
        return;
    }
    
    switch (sortBy) {
        case 'price-asc':
            currentProducts.sort((a, b) => parseFloat(a.price || 0) - parseFloat(b.price || 0));
            break;
        case 'price-desc':
            currentProducts.sort((a, b) => parseFloat(b.price || 0) - parseFloat(a.price || 0));
            break;
        case 'name-asc':
            currentProducts.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
            break;
        case 'name-desc':
            currentProducts.sort((a, b) => (b.name || '').localeCompare(a.name || ''));
            break;
        case 'newest':
        default:
            // Assume newer products have newest IDs or date fields
            // You can adjust this logic based on your data structure
            currentProducts.sort((a, b) => {
                if (a.new && !b.new) return -1;
                if (!a.new && b.new) return 1;
                return 0;
            });
            break;
    }
}

/**
 * Update product count display
 */
function updateProductCount() {
    if (productCountElement) {
        productCountElement.textContent = `${currentProducts.length} product${currentProducts.length !== 1 ? 's' : ''}`;
    }
}

/**
 * Display products in grid
 */
function displayProducts() {
        if (!productsGrid) {
            console.error('Products grid element not found');
            return;
        }
        
        // Clear existing content
        productsGrid.innerHTML = '';
        
    // Show empty state if no products
    if (!currentProducts || currentProducts.length === 0) {
        productsGrid.style.display = 'none';
        emptyState.style.display = 'block';
            return;
        }
        
    // Show products grid
    productsGrid.style.display = 'grid';
    emptyState.style.display = 'none';
    
    // Debug first few products
    if (currentProducts.length > 0) {
        console.log('First product details:', currentProducts[0]);
        if (currentProducts[0].image) {
            console.log('First product image path:', currentProducts[0].image);
        }
    }
    
    // Add product cards
    currentProducts.forEach(product => {
        try {
            // Fix common image path issues before creating card
            if (product.image && typeof product.image === 'string') {
                // Remove any double slashes except in http://
                product.image = product.image.replace(/([^:])\/\//g, '$1/');
                
                // If the path includes spaces, encode them
                if (product.image.includes(' ')) {
                    product.image = product.image.replace(/ /g, '%20');
                }
            }
            
            const productCard = createProductCard(product);
            productsGrid.appendChild(productCard);
        } catch (error) {
            console.error(`Error creating product card:`, error, product);
        }
    });
}

/**
 * Create product card element
 */
function createProductCard(product) {
    if (!product) {
        throw new Error('Invalid product data');
    }
    
    // Ensure all properties have default values
    const safeProduct = {
        id: product.id || 'unknown',
        name: product.name || 'Unnamed Product',
        price: product.price || 0,
        category: product.category || 'uncategorized',
        description: product.description || 'No description available',
        image: product.image || ''
    };
    
    // Fix image path
    let imagePath = safeProduct.image;
    
    // If there's no image or it's an invalid path, create a placeholder
    if (!imagePath || imagePath === "" || imagePath === "undefined") {
        imagePath = createCategoryPlaceholder(safeProduct.category, safeProduct.name);
    } 
    // If it's a server path but doesn't start with /
    else if (imagePath.includes('image/') && !imagePath.startsWith('/') && !imagePath.startsWith('data:')) {
        imagePath = '/' + imagePath;
    }
    // If it's just a filename with an extension, construct the full path
    else if (!imagePath.includes('/') && !imagePath.startsWith('data:') && imagePath.includes('.')) {
        const categoryPath = getImageCategoryPath(safeProduct.category);
        imagePath = `/image/${categoryPath}/${imagePath}`;
    }
    
    // Ensure there are no spaces in the URL
    if (imagePath.includes(' ') && !imagePath.startsWith('data:')) {
        imagePath = imagePath.replace(/ /g, '%20');
    }
    
    // Fix paths with bade instead of beds
    if (imagePath.includes('/bade/') || imagePath.includes('\\bade\\')) {
        imagePath = imagePath.replace('/bade/', '/beds/').replace('\\bade\\', '\\beds\\');
    }
    
    // Use template as base if available
    let card;
    const template = document.getElementById('product-template');
    if (template) {
        // Clone template
        card = template.content.cloneNode(true).querySelector('.product-card');
    } else {
        // Create product card element manually
        card = document.createElement('div');
        card.className = 'product-card';
        
        // Add content
        card.innerHTML = `
            <div class="product-image">
                <img src="${imagePath}" alt="${safeProduct.name}" loading="lazy" onerror="this.onerror=null; this.src='${createCategoryPlaceholder(safeProduct.category, safeProduct.name)}'">
                <div class="product-quick-actions">
                    <button class="action-btn" title="Quick View">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn" title="Add to Wishlist">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
            <div class="product-info">
                <span class="category-tag ${getCategoryClass(safeProduct.category)}">${getCategoryName(safeProduct.category)}</span>
                <h3 class="product-title">${safeProduct.name}</h3>
                <p class="product-description">${limitText(safeProduct.description, 100)}</p>
                <div class="product-footer">
                    <span class="product-price">ETB ${parseFloat(safeProduct.price).toFixed(2)}</span>
                    <a href="product.html?id=${safeProduct.id}" class="btn btn-primary btn-sm">View Details</a>
                </div>
            </div>
        `;
    }
    
    // If using template, update content
    if (template) {
        // Update image
        const img = card.querySelector('.product-image img');
        if (img) {
            img.src = imagePath;
            img.alt = safeProduct.name;
            img.onerror = function() {
                this.onerror = null;
                this.src = createCategoryPlaceholder(safeProduct.category, safeProduct.name);
            };
        }
        
        // Update text content
        const categoryTag = card.querySelector('.category-tag');
        if (categoryTag) {
            categoryTag.className = 'category-tag ' + getCategoryClass(safeProduct.category);
            categoryTag.textContent = getCategoryName(safeProduct.category);
        }
        
        const title = card.querySelector('.product-title');
        if (title) title.textContent = safeProduct.name;
        
        const description = card.querySelector('.product-description');
        if (description) description.textContent = limitText(safeProduct.description, 100);
        
        const price = card.querySelector('.product-price');
        if (price) price.textContent = 'ETB ' + parseFloat(safeProduct.price).toFixed(2);
        
        const detailsBtn = card.querySelector('.btn');
        if (detailsBtn) detailsBtn.href = `product.html?id=${safeProduct.id}`;
    }
    
    // Add click event for the entire card
    card.addEventListener('click', function(e) {
        // If clicked on a button or link, let the default behavior happen
        if (e.target.closest('.btn') || e.target.closest('.action-btn')) {
            return;
        }
        
        // Otherwise navigate to product detail page
        window.location.href = `product.html?id=${safeProduct.id}`;
    });
    
    // Add quick action button events
    const quickViewBtn = card.querySelector('.action-btn[title="Quick View"]');
    if (quickViewBtn) {
        quickViewBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            // Implement quick view functionality if needed
            window.location.href = `product.html?id=${safeProduct.id}`;
        });
    }
    
    const wishlistBtn = card.querySelector('.action-btn[title="Add to Wishlist"]');
    if (wishlistBtn) {
        wishlistBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            // Implement wishlist functionality if needed
            alert(`Added ${safeProduct.name} to wishlist`);
        });
    }
    
    return card;
}

/**
 * Create a styled placeholder image for a specific category
 */
function createCategoryPlaceholder(category, productName) {
    // Colors for different categories
    const colors = {
        sofas: '#f43f5e',      // Pink
        tables: '#10b981',     // Green
        chairs: '#3b82f6',     // Blue
        beds: '#8b5cf6',       // Purple
        bade: '#8b5cf6',       // Purple (keeping for backward compatibility)
        default: '#6b7280'     // Gray
    };
    
    // Get color based on category
    const bgColor = colors[category] || colors.default;
    const textColor = '#ffffff';
    
    // Get first letter of category name or use a default icon
    const displayText = productName && productName.length > 0 ? 
        productName.charAt(0).toUpperCase() : 
        category.charAt(0).toUpperCase();
    
    // Generate SVG
    const svg = `
    <svg width="300" height="300" xmlns="http://www.w3.org/2000/svg">
        <rect width="300" height="300" fill="${bgColor}" />
        <text fill="${textColor}" font-family="Arial" font-size="100" font-weight="bold" text-anchor="middle" x="150" y="180">${displayText}</text>
    </svg>`;
    
    // Convert to data URI
    return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
}

/**
 * Helper function to fix category references in path construction
 */
function getImageCategoryPath(category) {
    // Map 'bade' to 'beds' for image paths
    if (category === 'bade') {
        return 'beds';
    }
    return category;
}

/**
 * Get CSS class for category tag
 */
function getCategoryClass(category) {
    const categoryClasses = {
        'chairs': 'bg-chairs',
        'sofas': 'bg-sofas',
        'tables': 'bg-tables',
        'lighting': 'bg-lighting',
        'accessories': 'bg-accessories',
        'beds': 'bg-beds',
        'bade': 'bg-beds'  // Map bade to beds class
    };
    
    return categoryClasses[category] || 'bg-chairs';
}

/**
 * Get display name for category
 */
function getCategoryName(categoryId) {
    const categoryNames = {
        'chairs': 'Chairs',
        'sofas': 'Sofas',
        'tables': 'Tables',
        'lighting': 'Lighting',
        'accessories': 'Accessories',
        'beds': 'Beds',
        'bade': 'Beds'  // Map bade to Beds
    };
    
    return categoryNames[categoryId] || categoryId.charAt(0).toUpperCase() + categoryId.slice(1);
}

/**
 * Limit text to specific length with ellipsis
 */
function limitText(text, limit) {
    if (!text) return '';
    if (text.length <= limit) return text;
    return text.substring(0, limit).trim() + '...';
}

/**
 * Create a placeholder image data URL
 */
function createPlaceholderImage() {
    // Create a placeholder SVG as a data URI for consistent image placeholders
    return "data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22300%22%20height%3D%22300%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Crect%20width%3D%22300%22%20height%3D%22300%22%20fill%3D%22%234a5568%22%2F%3E%3Ctext%20fill%3D%22%23cbd5e0%22%20font-family%3D%22Arial%22%20font-size%3D%2220%22%20text-anchor%3D%22middle%22%20x%3D%22150%22%20y%3D%22150%22%3ENo%20Image%3C%2Ftext%3E%3C%2Fsvg%3E";
}

/**
 * Show/hide loading state
 */
function showLoading(isLoading) {
    if (loadingContainer) {
        loadingContainer.style.display = isLoading ? 'flex' : 'none';
    }
    
    if (productsGrid) {
        productsGrid.style.display = isLoading ? 'none' : 'grid';
    }
}

/**
 * Show error message
 */
function showError(message) {
    if (emptyState) {
        const title = emptyState.querySelector('h3');
        const description = emptyState.querySelector('p');
        const icon = emptyState.querySelector('.empty-icon i');
        
        if (title) title.textContent = 'Error';
        if (description) description.textContent = message;
        if (icon) {
            icon.className = '';
            icon.classList.add('fas', 'fa-exclamation-circle');
            icon.style.color = '#f43f5e';
        }
        
        emptyState.style.display = 'block';
        loadingContainer.style.display = 'none';
        productsGrid.style.display = 'none';
    }
}

/**
 * Initialize category select dropdown
 */
function initCategorySelect() {
    const categorySelect = document.getElementById('categorySelect');
    
    if (categorySelect) {
        // Set initial value based on current category
        if (currentCategory) {
            // Handle 'bade' vs 'beds' mapping
            const selectValue = currentCategory;
            categorySelect.value = selectValue;
        }
        
        // Add change event listener
        categorySelect.addEventListener('change', () => {
            const selectedCategory = categorySelect.value;
            
            if (selectedCategory === '') {
                window.location.href = `products.html${currentSort !== 'newest' ? `?sort=${currentSort}` : ''}`;
            } else {
                window.location.href = `products.html?category=${selectedCategory}${currentSort !== 'newest' ? `&sort=${currentSort}` : ''}`;
            }
        });
    }
} 