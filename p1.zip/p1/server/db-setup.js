const mysql = require('mysql2/promise');
const fs = require('fs').promises;
const path = require('path');

async function setupDatabase() {
    let connection;
    
    try {
        // Create connection to MySQL server (without database)
        connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: '' // Set your MySQL password here
        });
        
        console.log('Connected to MySQL server');
        
        // Create database if it doesn't exist
        await connection.query('CREATE DATABASE IF NOT EXISTS asamere_furniture');
        console.log('Database created or already exists');
        
        // Close connection and reconnect with the database
        await connection.end();
        
        connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: '', // Set your MySQL password here
            database: 'asamere_furniture'
        });
        
        console.log('Connected to asamere_furniture database');
        
        // Create products table
        await connection.query(`
            CREATE TABLE IF NOT EXISTS products (
                id VARCHAR(50) PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                category VARCHAR(50) NOT NULL,
                description TEXT,
                price DECIMAL(10, 2) NOT NULL,
                image VARCHAR(255),
                featured BOOLEAN DEFAULT FALSE,
                inStock BOOLEAN DEFAULT TRUE,
                new BOOLEAN DEFAULT FALSE,
                rating DECIMAL(3, 1) DEFAULT 0,
                reviewCount INT DEFAULT 0,
                specs JSON,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `);
        console.log('Products table created or already exists');
        
        // Create categories table
        await connection.query(`
            CREATE TABLE IF NOT EXISTS categories (
                id VARCHAR(50) PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                count INT DEFAULT 0,
                description TEXT
            )
        `);
        console.log('Categories table created or already exists');

        // Create users table
        await connection.query(`
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                email VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                salt VARCHAR(255) NOT NULL,
                role ENUM('admin', 'customer') DEFAULT 'customer',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `);
        console.log('Users table created or already exists');

        // Create orders table
        await connection.query(`
            CREATE TABLE IF NOT EXISTS orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                customer_name VARCHAR(100) NOT NULL,
                customer_email VARCHAR(100) NOT NULL,
                customer_address TEXT NOT NULL,
                total_amount DECIMAL(10, 2) NOT NULL,
                payment_method VARCHAR(50) DEFAULT 'credit_card',
                status ENUM('pending', 'processing', 'shipped', 'delivered', 'canceled') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `);
        console.log('Orders table created or already exists');

        // Create order_items table
        await connection.query(`
            CREATE TABLE IF NOT EXISTS order_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                product_id VARCHAR(50) NOT NULL,
                quantity INT NOT NULL DEFAULT 1,
                price DECIMAL(10, 2) NOT NULL,
                subtotal DECIMAL(10, 2) NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
            )
        `);
        console.log('Order items table created or already exists');
        
        // Check if we already have users
        const [users] = await connection.query('SELECT COUNT(*) AS count FROM users');
        
        if (users[0].count === 0) {
            // Create default admin user
            const crypto = require('crypto');
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = crypto.pbkdf2Sync('admin123', salt, 1000, 64, 'sha512').toString('hex');
            
            await connection.query(`
                INSERT INTO users (username, email, password, salt, role)
                VALUES ('admin', 'admin@asamere.com', ?, ?, 'admin')
            `, [hash, salt]);
            
            console.log('Default admin user created');
        } else {
            console.log('Users already exist, skipping admin creation');
        }
        
        // Check if we already have categories
        const [categories] = await connection.query('SELECT COUNT(*) AS count FROM categories');
        
        if (categories[0].count === 0) {
            // Insert categories
            const categoriesToInsert = [
                {
                    id: 'chairs',
                    name: 'Chairs',
                    count: 0,
                    description: 'Comfortable and stylish chairs for your home or office. Our selection includes dining chairs, lounge chairs, and accent chairs.'
                },
                {
                    id: 'sofas',
                    name: 'Sofas',
                    count: 0,
                    description: 'Elegant and comfortable sofas to enhance your living room. Choose from various styles, materials, and colors.'
                },
                {
                    id: 'tables',
                    name: 'Tables',
                    count: 0,
                    description: 'Functional and beautiful tables for dining, coffee, side tables and more. Various designs to match your décor.'
                },
                {
                    id: 'lighting',
                    name: 'Lighting',
                    count: 0,
                    description: 'Illuminate your space with our contemporary lighting solutions. Floor lamps, table lamps, and ceiling fixtures.'
                },
                {
                    id: 'accessories',
                    name: 'Accessories',
                    count: 0,
                    description: 'Complete your interior with our curated accessories. Decorative items to add personality to any room.'
                },
                {
                    id: 'bade',
                    name: 'Beds',
                    count: 0,
                    description: 'Quality beds for restful sleep. Our collection includes various sizes and styles to suit any bedroom.'
                }
            ];
            
            for (const category of categoriesToInsert) {
                await connection.query(
                    'INSERT INTO categories (id, name, count, description) VALUES (?, ?, ?, ?)',
                    [category.id, category.name, category.count, category.description]
                );
            }
            
            console.log('Categories inserted');
        } else {
            console.log('Categories already exist, skipping insertion');
        }
        
        // Check if we already have products
        const [products] = await connection.query('SELECT COUNT(*) AS count FROM products');
        
        if (products[0].count === 0) {
            // Sample products to insert
            const productsToInsert = getSampleProducts();
            
            for (const product of productsToInsert) {
                // Convert specs object to JSON
                if (product.specs && typeof product.specs === 'object') {
                    product.specs = JSON.stringify(product.specs);
                }
                
                await connection.query(
                    `INSERT INTO products 
                    (id, name, category, description, price, image, featured, inStock, new, rating, reviewCount, specs) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        product.id,
                        product.name,
                        product.category,
                        product.description,
                        product.price,
                        product.image,
                        product.featured ? 1 : 0,
                        product.inStock ? 1 : 0,
                        product.new ? 1 : 0,
                        product.rating || 0,
                        product.reviewCount || 0,
                        product.specs || null
                    ]
                );
                
                // Update category count
                await connection.query(
                    'UPDATE categories SET count = count + 1 WHERE id = ?',
                    [product.category]
                );
            }
            
            console.log('Sample products inserted');
        } else {
            console.log('Products already exist, skipping insertion');
        }
        
        console.log('Database setup completed successfully');
    } catch (error) {
        console.error('Error setting up database:', error);
    } finally {
        if (connection) {
            await connection.end();
            console.log('Database connection closed');
        }
    }
}

function getSampleProducts() {
    return [
        // Chairs
        {
            id: 'c1',
            name: 'Contemporary Dining Chair',
            category: 'chairs',
            description: 'A modern dining chair with a sleek design and comfortable cushion. Perfect for dining rooms and kitchen areas.',
            price: 129.99,
            image: 'image/chairs/OIP (9).jpg',
            featured: true,
            inStock: true,
            new: false,
            rating: 4.7,
            reviewCount: 18,
            specs: {
                dimensions: '45x50x85 cm',
                weight: '5 kg',
                material: 'Fabric, Metal',
                colors: ['Gray', 'Blue', 'Black']
            }
        },
        {
            id: 'c2',
            name: 'Ergonomic Office Chair',
            category: 'chairs',
            description: 'An ergonomic office chair designed for maximum comfort during long work hours. Features adjustable height and lumbar support.',
            price: 249.99,
            image: 'image/chairs/OIP (10).jpg',
            featured: false,
            inStock: true,
            new: true,
            rating: 4.8,
            reviewCount: 24,
            specs: {
                dimensions: '65x65x120 cm',
                weight: '12 kg',
                material: 'Mesh, Plastic, Metal',
                colors: ['Black', 'Gray']
            }
        },
        {
            id: 'c3',
            name: 'Accent Lounge Chair',
            category: 'chairs',
            description: 'A stylish accent chair that adds character to any living space. Perfect for reading corners or small spaces.',
            price: 179.99,
            image: 'image/chairs/OIP (11).jpg',
            featured: false,
            inStock: true,
            new: false,
            rating: 4.5,
            reviewCount: 15,
            specs: {
                dimensions: '70x75x80 cm',
                weight: '8 kg',
                material: 'Fabric, Wood',
                colors: ['Teal', 'Mustard', 'Rose']
            }
        },
        {
            id: 'c4',
            name: 'Minimalist Wooden Chair',
            category: 'chairs',
            description: 'A minimalist wooden chair with clean lines and natural finish. Blends with various interior styles.',
            price: 99.99,
            image: 'image/chairs/OIP (12).jpg',
            featured: false,
            inStock: true,
            new: false,
            rating: 4.3,
            reviewCount: 12,
            specs: {
                dimensions: '40x45x80 cm',
                weight: '4 kg',
                material: 'Solid Wood',
                colors: ['Natural', 'Walnut', 'White']
            }
        },
        {
            id: 'c5',
            name: 'Swivel Bar Stool',
            category: 'chairs',
            description: 'A modern bar stool with swivel function and comfortable seat. Perfect for kitchen islands and home bars.',
            price: 149.99,
            image: 'image/chairs/OIP (13).jpg',
            featured: false,
            inStock: true,
            new: true,
            rating: 4.6,
            reviewCount: 9,
            specs: {
                dimensions: '40x40x100 cm',
                weight: '6 kg',
                material: 'Faux Leather, Metal',
                colors: ['Black', 'White', 'Brown']
            }
        },
        
        // Sofas
        {
            id: 's1',
            name: 'Modern 3-Seater Sofa',
            category: 'sofas',
            description: 'A spacious 3-seater sofa with clean lines and premium upholstery. Perfect for contemporary living rooms.',
            price: 899.99,
            image: 'image/sofas/OIP (9).jpg',
            featured: true,
            inStock: true,
            new: false,
            rating: 4.8,
            reviewCount: 32,
            specs: {
                dimensions: '220x95x85 cm',
                weight: '45 kg',
                material: 'Premium Fabric, Hardwood Frame',
                colors: ['Gray', 'Blue', 'Beige', 'Green']
            }
        },
        {
            id: 's2',
            name: 'Sectional Corner Sofa',
            category: 'sofas',
            description: 'A versatile sectional sofa with modular design. Can be arranged in multiple configurations to suit your space.',
            price: 1299.99,
            image: 'image/sofas/OIP (10).jpg',
            featured: true,
            inStock: true,
            new: true,
            rating: 4.7,
            reviewCount: 28,
            specs: {
                dimensions: '320x170x85 cm',
                weight: '65 kg',
                material: 'Performance Fabric, Engineered Wood',
                colors: ['Light Gray', 'Dark Gray', 'Navy']
            }
        },
        {
            id: 's3',
            name: 'Compact 2-Seater Sofa',
            category: 'sofas',
            description: 'A compact 2-seater sofa perfect for smaller living spaces. Combines comfort with a small footprint.',
            price: 599.99,
            image: 'image/sofas/OIP (11).jpg',
            featured: false,
            inStock: true,
            new: false,
            rating: 4.5,
            reviewCount: 17,
            specs: {
                dimensions: '160x85x80 cm',
                weight: '30 kg',
                material: 'Fabric, Solid Wood',
                colors: ['Beige', 'Light Blue', 'Charcoal']
            }
        },
        {
            id: 's4',
            name: 'Contemporary Loveseat',
            category: 'sofas',
            description: 'A stylish loveseat with plush cushions and elegant design. Perfect for creating intimate seating areas.',
            price: 499.99,
            image: 'image/sofas/OIP (12).jpg',
            featured: false,
            inStock: true,
            new: true,
            rating: 4.6,
            reviewCount: 14,
            specs: {
                dimensions: '140x85x80 cm',
                weight: '25 kg',
                material: 'Velvet, Solid Wood',
                colors: ['Emerald', 'Rose', 'Navy']
            }
        },
        {
            id: 's5',
            name: 'Convertible Sofa Bed',
            category: 'sofas',
            description: 'A practical sofa that converts into a comfortable bed. Perfect for guest rooms or maximizing space in apartments.',
            price: 799.99,
            image: 'image/sofas/OIP (13).jpg',
            featured: false,
            inStock: true,
            new: false,
            rating: 4.4,
            reviewCount: 22,
            specs: {
                dimensions: '200x90x85 cm (as sofa), 200x130x40 cm (as bed)',
                weight: '40 kg',
                material: 'Microfiber, Metal Frame',
                colors: ['Gray', 'Black', 'Brown']
            }
        },
        
        // Tables
        {
            id: 't1',
            name: 'Solid Oak Dining Table',
            category: 'tables',
            description: 'A beautiful solid oak dining table that comfortably seats 6 people. The timeless design fits with various interior styles.',
            price: 799.99,
            image: 'image/tables/OIP (9).jpg',
            featured: true,
            inStock: true,
            new: false,
            rating: 4.9,
            reviewCount: 30,
            specs: {
                dimensions: '180x90x75 cm',
                weight: '40 kg',
                material: 'Solid Oak',
                colors: ['Natural', 'Dark Oak']
            }
        },
        {
            id: 't2',
            name: 'Modern Coffee Table',
            category: 'tables',
            description: 'A sleek coffee table with clean lines and practical storage shelf. A perfect centerpiece for any living room.',
            price: 349.99,
            image: 'image/tables/OIP (10).jpg',
            featured: true,
            inStock: true,
            new: true,
            rating: 4.7,
            reviewCount: 19,
            specs: {
                dimensions: '120x60x45 cm',
                weight: '20 kg',
                material: 'Engineered Wood, Metal',
                colors: ['White/Oak', 'Black/Walnut']
            }
        },
        {
            id: 't3',
            name: 'Compact Side Table',
            category: 'tables',
            description: 'A compact side table perfect for small spaces. Features a sleek design with enough space for essentials.',
            price: 129.99,
            image: 'image/tables/OIP (11).jpg',
            featured: false,
            inStock: true,
            new: false,
            rating: 4.5,
            reviewCount: 12,
            specs: {
                dimensions: '45x45x50 cm',
                weight: '8 kg',
                material: 'Wood, Metal',
                colors: ['Natural/Black', 'White/Gold']
            }
        },
        {
            id: 't4',
            name: 'Extendable Dining Table',
            category: 'tables',
            description: 'A versatile dining table that extends to accommodate more guests. Perfect for spaces where flexibility is needed.',
            price: 899.99,
            image: 'image/tables/OIP (12).jpg',
            featured: false,
            inStock: true,
            new: true,
            rating: 4.8,
            reviewCount: 24,
            specs: {
                dimensions: '160-220x90x75 cm',
                weight: '50 kg',
                material: 'Solid Wood, Metal',
                colors: ['Oak', 'Walnut', 'White']
            }
        },
        {
            id: 't5',
            name: 'Glass Nesting Tables',
            category: 'tables',
            description: 'A set of 3 nesting tables with glass tops and metal frames. Versatile and can be used together or separately.',
            price: 249.99,
            image: 'image/tables/OIP (13).jpg',
            featured: false,
            inStock: true,
            new: false,
            rating: 4.6,
            reviewCount: 16,
            specs: {
                dimensions: 'Various sizes',
                weight: '15 kg (set)',
                material: 'Tempered Glass, Metal',
                colors: ['Clear/Gold', 'Smoked/Black']
            }
        },
        
        // Beds
        {
            id: 'b1',
            name: 'Modern Platform Bed',
            category: 'bade',
            description: 'A sleek platform bed with a low profile design. No box spring needed - designed for mattress only.',
            price: 699.99,
            image: 'image/bade/OIP (9).jpg',
            featured: true,
            inStock: true,
            new: false,
            rating: 4.7,
            reviewCount: 27,
            specs: {
                dimensions: '160x200x35 cm (Queen)',
                weight: '50 kg',
                material: 'Engineered Wood, Metal',
                colors: ['Walnut', 'Black', 'White']
            }
        },
        {
            id: 'b2',
            name: 'Upholstered Bed Frame',
            category: 'bade',
            description: 'A luxurious upholstered bed frame with a padded headboard. Adds elegance and comfort to any bedroom.',
            price: 899.99,
            image: 'image/bade/OIP (10).jpg',
            featured: false,
            inStock: true,
            new: true,
            rating: 4.9,
            reviewCount: 34,
            specs: {
                dimensions: '160x200x120 cm (Queen)',
                weight: '60 kg',
                material: 'Fabric, Solid Wood Frame',
                colors: ['Gray', 'Beige', 'Blue']
            }
        },
        {
            id: 'b3',
            name: 'Wooden Bed with Storage',
            category: 'bade',
            description: 'A practical wooden bed with integrated storage drawers. Perfect for maximizing bedroom space.',
            price: 799.99,
            image: 'image/bade/OIP (11).jpg',
            featured: true,
            inStock: true,
            new: false,
            rating: 4.8,
            reviewCount: 22,
            specs: {
                dimensions: '160x200x45 cm (Queen)',
                weight: '70 kg',
                material: 'Solid Wood',
                colors: ['Oak', 'Cherry', 'Espresso']
            }
        },
        {
            id: 'b4',
            name: 'Minimalist Metal Bed',
            category: 'bade',
            description: 'A sleek metal bed frame with a minimalist design. Sturdy construction with a clean, modern aesthetic.',
            price: 499.99,
            image: 'image/bade/OIP (12).jpg',
            featured: false,
            inStock: true,
            new: true,
            rating: 4.6,
            reviewCount: 19,
            specs: {
                dimensions: '160x200x40 cm (Queen)',
                weight: '35 kg',
                material: 'Metal',
                colors: ['Black', 'White', 'Gold']
            }
        },
        {
            id: 'b5',
            name: 'Canopy Bed Frame',
            category: 'bade',
            description: 'An elegant four-poster canopy bed that creates a dramatic focal point in your bedroom. Classic design with modern touches.',
            price: 1099.99,
            image: 'image/bade/OIP (13).jpg',
            featured: true,
            inStock: true,
            new: false,
            rating: 4.9,
            reviewCount: 31,
            specs: {
                dimensions: '160x200x210 cm (Queen)',
                weight: '75 kg',
                material: 'Metal, Fabric Canopy Optional',
                colors: ['Black', 'White', 'Brass']
            }
        }
    ];
}

// Run the setup function
setupDatabase()
    .then(() => process.exit(0))
    .catch(error => {
        console.error('Error:', error);
        process.exit(1);
    }); 