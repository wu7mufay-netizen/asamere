const express = require('express');
const upload = require('../middleware/uploadMiddleware');
const authController = require('../controllers/authController');
const path = require('path');

const router = express.Router();

// Upload product image (admin only)
router.post('/product-image', 
    authController.authenticate, 
    authController.isAdmin, 
    upload.single('image'), 
    (req, res) => {
        try {
            if (!req.file) {
                return res.status(400).json({ error: 'No file uploaded' });
            }
            
            // Format the file URL to be accessible from the client
            const fileUrl = `/uploads/${path.basename(req.file.path)}`;
            
            res.json({
                message: 'File uploaded successfully',
                imageUrl: fileUrl,
                file: {
                    filename: req.file.filename,
                    size: req.file.size,
                    mimetype: req.file.mimetype
                }
            });
        } catch (error) {
            console.error('Error uploading file:', error);
            res.status(500).json({ error: 'Failed to upload file' });
        }
    }
);

// Handle errors from multer
router.use((err, req, res, next) => {
    if (err.message && (err.message.includes('file size') || err.message.includes('file type'))) {
        return res.status(400).json({ error: err.message });
    }
    next(err);
});

module.exports = router; 