const express = require('express');
const categoryController = require('../controllers/categoryController');
const authController = require('../controllers/authController');

const router = express.Router();

// Public routes
router.get('/', categoryController.getAllCategories);
router.get('/:id', categoryController.getCategoryById);

// Protected routes (admin only)
router.post('/', authController.authenticate, authController.isAdmin, categoryController.createCategory);
router.put('/:id', authController.authenticate, authController.isAdmin, categoryController.updateCategory);
router.delete('/:id', authController.authenticate, authController.isAdmin, categoryController.deleteCategory);
router.post('/recalculate', authController.authenticate, authController.isAdmin, categoryController.recalculateCounts);

module.exports = router; 