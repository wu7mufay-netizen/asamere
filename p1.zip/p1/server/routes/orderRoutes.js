const express = require('express');
const orderController = require('../controllers/orderController');
const authController = require('../controllers/authController');

const router = express.Router();

// Public routes (for placing orders)
router.post('/', orderController.createOrder);

// Protected routes (admin only)
router.get('/', authController.authenticate, authController.isAdmin, orderController.getAllOrders);
router.get('/:id', authController.authenticate, authController.isAdmin, orderController.getOrderById);
router.put('/:id/status', authController.authenticate, authController.isAdmin, orderController.updateOrderStatus);
router.delete('/:id', authController.authenticate, authController.isAdmin, orderController.deleteOrder);

module.exports = router; 