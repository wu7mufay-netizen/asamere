const express = require('express');
const authController = require('../controllers/authController');

const router = express.Router();

// Public routes
router.post('/login', authController.login);
router.post('/register', authController.register);

// Protected routes
router.get('/profile', authController.authenticate, authController.getProfile);
router.get('/check', authController.authenticate, authController.checkAuth);

module.exports = router; 