const express = require('express');
const productController = require('../controllers/productController');
const authController = require('../controllers/authController');

const router = express.Router();

// Public routes
router.get('/', productController.getAllProducts);
router.get('/category/:category', productController.getProductsByCategory);
router.get('/featured/items', productController.getFeaturedProducts);
router.get('/new/arrivals', productController.getNewArrivals);
router.get('/search/items', productController.searchProducts);
router.get('/:id', productController.getProductById);

// Protected routes (admin only)
router.post('/', authController.authenticate, authController.isAdmin, productController.createProduct);
router.put('/:id', authController.authenticate, authController.isAdmin, productController.updateProduct);
router.delete('/:id', authController.authenticate, authController.isAdmin, productController.deleteProduct);

module.exports = router; 