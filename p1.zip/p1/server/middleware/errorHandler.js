// Error handling middleware
const errorHandler = (err, req, res, next) => {
    console.error('Error caught by middleware:', err);
    
    // Check if response is already sent
    if (res.headersSent) {
        return next(err);
    }
    
    // Determine status code and error message
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Internal Server Error';
    
    // Send error response
    res.status(statusCode).json({
        error: message,
        stack: process.env.NODE_ENV === 'production' ? undefined : err.stack
    });
};

module.exports = errorHandler; 