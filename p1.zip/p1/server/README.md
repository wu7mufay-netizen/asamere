# Asamere Furniture Server

This is the backend server for the Asamere Furniture e-commerce website. It provides RESTful API endpoints for managing products, categories, orders, and user authentication.

## Prerequisites

- Node.js (v14+)
- MySQL (v5.7+)

## Setup

1. Install dependencies:

```bash
npm install
```

2. Configure the database connection in `models/database.js` (update MySQL credentials if needed).

3. Run the database setup script to create the database, tables, and sample data:

```bash
npm run setup
```

4. Start the server:

```bash
npm start
```

For development with automatic restart:

```bash
npm run dev
```

## API Endpoints

### Products

- `GET /api/products` - Get all products
- `GET /api/products/:id` - Get product by ID
- `GET /api/products/category/:category` - Get products by category
- `GET /api/products/featured/items` - Get featured products
- `GET /api/products/new/arrivals` - Get new arrivals
- `GET /api/products/search/items?term=xyz` - Search products
- `POST /api/products` - Create product (Admin only)
- `PUT /api/products/:id` - Update product (Admin only)
- `DELETE /api/products/:id` - Delete product (Admin only)

### Categories

- `GET /api/categories` - Get all categories
- `GET /api/categories/:id` - Get category by ID
- `POST /api/categories` - Create category (Admin only)
- `PUT /api/categories/:id` - Update category (Admin only)
- `DELETE /api/categories/:id` - Delete category (Admin only)
- `POST /api/categories/recalculate` - Recalculate category counts (Admin only)

### Orders

- `POST /api/orders` - Create new order
- `GET /api/orders` - Get all orders (Admin only)
- `GET /api/orders/:id` - Get order by ID (Admin only)
- `PUT /api/orders/:id/status` - Update order status (Admin only)
- `DELETE /api/orders/:id` - Delete order (Admin only)

### Authentication

- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/profile` - Get user profile (Authenticated)
- `GET /api/auth/check` - Check if token is valid (Authenticated)

### System

- `GET /api/setup` - Setup database tables
- `GET /api/health-check` - Check server health

## Authentication

Protected routes require a JWT token in the Authorization header:

```
Authorization: Bearer <token>
```

## Default Admin User

After setup, you can log in with these credentials:

- Username: `admin`
- Password: `admin123`

## Project Structure

```
server/
├── controllers/      # Request handlers
├── models/           # Database models
├── routes/           # API routes
├── middleware/       # Middleware functions
├── db-setup.js       # Database setup script
├── server.js         # Main server file
└── package.json      # Dependencies and scripts
``` 