const Category = require('../models/category');

// Get all categories
exports.getAllCategories = async (req, res) => {
    try {
        const rows = await Category.getAll();
        
        // Convert to object format expected by the client
        const categories = {};
        rows.forEach(category => {
            categories[category.id] = {
                id: category.id,
                name: category.name,
                count: category.count,
                description: category.description
            };
        });
        
        res.json(categories);
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
};

// Get category by ID
exports.getCategoryById = async (req, res) => {
    try {
        const category = await Category.getById(req.params.id);
        
        if (!category) {
            return res.status(404).json({ error: 'Category not found' });
        }
        
        res.json(category);
    } catch (error) {
        console.error(`Error fetching category with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to fetch category' });
    }
};

// Create category
exports.createCategory = async (req, res) => {
    try {
        const category = req.body;
        
        // Validate required fields
        if (!category.id || !category.name) {
            return res.status(400).json({ error: 'ID and name are required' });
        }
        
        const result = await Category.create(category);
        res.status(201).json({ 
            message: 'Category created successfully', 
            categoryId: result.id 
        });
    } catch (error) {
        console.error('Error creating category:', error);
        res.status(500).json({ error: 'Failed to create category' });
    }
};

// Update category
exports.updateCategory = async (req, res) => {
    try {
        const category = req.body;
        const categoryId = req.params.id;
        
        // Validate required fields
        if (!category.name) {
            return res.status(400).json({ error: 'Name is required' });
        }
        
        const result = await Category.update(categoryId, category);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Category not found' });
        }
        
        res.json({ message: 'Category updated successfully' });
    } catch (error) {
        console.error(`Error updating category with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to update category' });
    }
};

// Delete category
exports.deleteCategory = async (req, res) => {
    try {
        const result = await Category.delete(req.params.id);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Category not found' });
        }
        
        res.json({ message: 'Category deleted successfully' });
    } catch (error) {
        if (error.message && error.message.includes('Cannot delete category')) {
            return res.status(400).json({ error: error.message });
        }
        
        console.error(`Error deleting category with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to delete category' });
    }
};

// Recalculate category counts
exports.recalculateCounts = async (req, res) => {
    try {
        await Category.recalculateCounts();
        res.json({ message: 'Category counts recalculated successfully' });
    } catch (error) {
        console.error('Error recalculating category counts:', error);
        res.status(500).json({ error: 'Failed to recalculate category counts' });
    }
}; 