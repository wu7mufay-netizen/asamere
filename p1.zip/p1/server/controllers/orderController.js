const Order = require('../models/order');

// Get all orders
exports.getAllOrders = async (req, res) => {
    try {
        const orders = await Order.getAll();
        res.json(orders);
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).json({ error: 'Failed to fetch orders' });
    }
};

// Get order by ID
exports.getOrderById = async (req, res) => {
    try {
        const order = await Order.getById(req.params.id);
        
        if (!order) {
            return res.status(404).json({ error: 'Order not found' });
        }
        
        res.json(order);
    } catch (error) {
        console.error(`Error fetching order with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to fetch order' });
    }
};

// Create order
exports.createOrder = async (req, res) => {
    try {
        const order = req.body;
        
        // Validate required fields
        if (!order.customer_name || !order.customer_email || !order.customer_address || !order.total_amount) {
            return res.status(400).json({ 
                error: 'Customer name, email, address, and total amount are required' 
            });
        }
        
        // Validate order items
        if (!order.items || !Array.isArray(order.items) || order.items.length === 0) {
            return res.status(400).json({ error: 'At least one order item is required' });
        }
        
        const result = await Order.create(order);
        res.status(201).json({ 
            message: 'Order created successfully', 
            orderId: result.id 
        });
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(500).json({ error: 'Failed to create order' });
    }
};

// Update order status
exports.updateOrderStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const orderId = req.params.id;
        
        // Validate required fields
        if (!status) {
            return res.status(400).json({ error: 'Status is required' });
        }
        
        // Validate status value
        const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'canceled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ error: `Status must be one of: ${validStatuses.join(', ')}` });
        }
        
        const result = await Order.updateStatus(orderId, status);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Order not found' });
        }
        
        res.json({ message: 'Order status updated successfully' });
    } catch (error) {
        console.error(`Error updating order status with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to update order status' });
    }
};

// Delete order
exports.deleteOrder = async (req, res) => {
    try {
        const result = await Order.delete(req.params.id);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Order not found' });
        }
        
        res.json({ message: 'Order deleted successfully' });
    } catch (error) {
        console.error(`Error deleting order with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to delete order' });
    }
}; 