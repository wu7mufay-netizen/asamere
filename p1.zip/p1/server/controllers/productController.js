const Product = require('../models/product');

// Get all products
exports.getAllProducts = async (req, res) => {
    try {
        const products = await Product.getAll();
        
        // Add full URLs for images
        const productsWithFormattedImages = products.map(product => {
            if (product.image) {
                // Make sure image URLs are absolute from the client perspective
                if (!product.image.startsWith('http') && !product.image.startsWith('/')) {
                    product.image = `/${product.image}`;
                }
            }
            return product;
        });
        
        res.json(productsWithFormattedImages);
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Failed to fetch products' });
    }
};

// Get product by ID
exports.getProductById = async (req, res) => {
    try {
        const product = await Product.getById(req.params.id);
        
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        
        res.json(product);
    } catch (error) {
        console.error(`Error fetching product with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to fetch product' });
    }
};

// Get products by category
exports.getProductsByCategory = async (req, res) => {
    try {
        const products = await Product.getByCategory(req.params.category);
        res.json(products);
    } catch (error) {
        console.error(`Error fetching products in category ${req.params.category}:`, error);
        res.status(500).json({ error: 'Failed to fetch products by category' });
    }
};

// Get featured products
exports.getFeaturedProducts = async (req, res) => {
    try {
        const products = await Product.getFeatured();
        res.json(products);
    } catch (error) {
        console.error('Error fetching featured products:', error);
        res.status(500).json({ error: 'Failed to fetch featured products' });
    }
};

// Get new arrivals
exports.getNewArrivals = async (req, res) => {
    try {
        const products = await Product.getNewArrivals();
        res.json(products);
    } catch (error) {
        console.error('Error fetching new arrivals:', error);
        res.status(500).json({ error: 'Failed to fetch new arrivals' });
    }
};

// Search products
exports.searchProducts = async (req, res) => {
    try {
        const products = await Product.search(req.query.term);
        res.json(products);
    } catch (error) {
        console.error('Error searching products:', error);
        res.status(500).json({ error: 'Failed to search products' });
    }
};

// Create product
exports.createProduct = async (req, res) => {
    try {
        const product = req.body;
        
        // Validate required fields
        if (!product.name || !product.category || !product.price) {
            return res.status(400).json({ error: 'Name, category, and price are required' });
        }
        
        // If no image was provided, set a default image
        if (!product.image) {
            product.image = '/image/placeholder.jpg';
        }
        
        const result = await Product.create(product);
        res.status(201).json({ 
            message: 'Product created successfully', 
            productId: result.id 
        });
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({ error: 'Failed to create product' });
    }
};

// Update product
exports.updateProduct = async (req, res) => {
    try {
        const product = req.body;
        const productId = req.params.id;
        
        // Validate required fields
        if (!product.name || !product.category || !product.price) {
            return res.status(400).json({ error: 'Name, category, and price are required' });
        }
        
        // Handle image field - keep existing image if not provided
        if (!product.image) {
            const existingProduct = await Product.getById(productId);
            if (existingProduct) {
                product.image = existingProduct.image;
            }
        }
        
        const result = await Product.update(productId, product);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }
        
        res.json({ message: 'Product updated successfully' });
    } catch (error) {
        console.error(`Error updating product with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to update product' });
    }
};

// Delete product
exports.deleteProduct = async (req, res) => {
    try {
        const result = await Product.delete(req.params.id);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }
        
        res.json({ message: 'Product deleted successfully' });
    } catch (error) {
        console.error(`Error deleting product with ID ${req.params.id}:`, error);
        res.status(500).json({ error: 'Failed to delete product' });
    }
}; 