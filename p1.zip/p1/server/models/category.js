const { pool } = require('./database');

class Category {
    // Get all categories
    static async getAll() {
        try {
            const [rows] = await pool.query('SELECT * FROM categories');
            return rows;
        } catch (error) {
            console.error('Error in getAll categories:', error);
            throw error;
        }
    }

    // Get category by ID
    static async getById(id) {
        try {
            const [rows] = await pool.query('SELECT * FROM categories WHERE id = ?', [id]);
            return rows.length ? rows[0] : null;
        } catch (error) {
            console.error(`Error in getById category (${id}):`, error);
            throw error;
        }
    }

    // Create category
    static async create(category) {
        try {
            const [result] = await pool.query(
                'INSERT INTO categories (id, name, count, description) VALUES (?, ?, ?, ?)',
                [category.id, category.name, category.count || 0, category.description]
            );
            return { id: category.id, ...result };
        } catch (error) {
            console.error('Error in create category:', error);
            throw error;
        }
    }

    // Update category
    static async update(id, category) {
        try {
            const [result] = await pool.query(
                'UPDATE categories SET name = ?, description = ? WHERE id = ?',
                [category.name, category.description, id]
            );
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in update category (${id}):`, error);
            throw error;
        }
    }

    // Delete category
    static async delete(id) {
        try {
            // First check if there are products in this category
            const [products] = await pool.query('SELECT COUNT(*) as count FROM products WHERE category = ?', [id]);
            if (products[0].count > 0) {
                throw new Error(`Cannot delete category with ${products[0].count} products assigned to it`);
            }
            
            const [result] = await pool.query('DELETE FROM categories WHERE id = ?', [id]);
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in delete category (${id}):`, error);
            throw error;
        }
    }

    // Update category count
    static async updateCount(id, delta = 1) {
        try {
            const [result] = await pool.query(
                'UPDATE categories SET count = count + ? WHERE id = ?',
                [delta, id]
            );
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in updateCount category (${id}):`, error);
            throw error;
        }
    }

    // Recalculate all category counts
    static async recalculateCounts() {
        try {
            const [categories] = await pool.query('SELECT id FROM categories');
            
            for (const category of categories) {
                const [products] = await pool.query(
                    'SELECT COUNT(*) as count FROM products WHERE category = ?',
                    [category.id]
                );
                
                await pool.query(
                    'UPDATE categories SET count = ? WHERE id = ?',
                    [products[0].count, category.id]
                );
            }
            
            return { success: true };
        } catch (error) {
            console.error('Error in recalculateCounts:', error);
            throw error;
        }
    }
}

module.exports = Category; 