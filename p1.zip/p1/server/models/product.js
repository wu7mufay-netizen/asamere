const { pool } = require('./database');

class Product {
    // Get all products
    static async getAll() {
        try {
            const [rows] = await pool.query('SELECT * FROM products');
            return rows;
        } catch (error) {
            console.error('Error in getAll products:', error);
            throw error;
        }
    }

    // Get product by ID
    static async getById(id) {
        try {
            const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
            return rows.length ? rows[0] : null;
        } catch (error) {
            console.error(`Error in getById product (${id}):`, error);
            throw error;
        }
    }

    // Get products by category
    static async getByCategory(category) {
        try {
            const [rows] = await pool.query('SELECT * FROM products WHERE category = ?', [category]);
            return rows;
        } catch (error) {
            console.error(`Error in getByCategory products (${category}):`, error);
            throw error;
        }
    }

    // Get featured products
    static async getFeatured() {
        try {
            const [rows] = await pool.query('SELECT * FROM products WHERE featured = 1');
            return rows;
        } catch (error) {
            console.error('Error in getFeatured products:', error);
            throw error;
        }
    }

    // Get new arrivals
    static async getNewArrivals() {
        try {
            const [rows] = await pool.query('SELECT * FROM products WHERE new = 1');
            return rows;
        } catch (error) {
            console.error('Error in getNewArrivals products:', error);
            throw error;
        }
    }

    // Search products
    static async search(term) {
        try {
            const searchTerm = `%${term}%`;
            const [rows] = await pool.query(
                'SELECT * FROM products WHERE name LIKE ? OR description LIKE ? OR category LIKE ?', 
                [searchTerm, searchTerm, searchTerm]
            );
            return rows;
        } catch (error) {
            console.error(`Error in search products (${term}):`, error);
            throw error;
        }
    }

    // Create product
    static async create(product) {
        try {
            // Convert specs object to JSON string if it exists
            if (product.specs && typeof product.specs === 'object') {
                product.specs = JSON.stringify(product.specs);
            }
            
            // Ensure image URL is properly formatted
            let imageUrl = product.image;
            if (imageUrl && imageUrl.startsWith('/uploads/')) {
                // Already correctly formatted
                imageUrl = product.image;
            } else if (imageUrl && !imageUrl.startsWith('http')) {
                // Only add the prefix if it's not already an absolute URL
                imageUrl = `/uploads/${imageUrl.replace(/^\/+/, '')}`;
            }
            
            const [result] = await pool.query(
                `INSERT INTO products 
                (id, name, category, description, price, image, featured, inStock, new, rating, reviewCount, specs) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    product.id,
                    product.name,
                    product.category,
                    product.description,
                    product.price,
                    imageUrl,
                    product.featured ? 1 : 0,
                    product.inStock ? 1 : 0,
                    product.new ? 1 : 0,
                    product.rating || 0,
                    product.reviewCount || 0,
                    product.specs || null
                ]
            );

            // Update category count
            await pool.query(
                'UPDATE categories SET count = count + 1 WHERE id = ?',
                [product.category]
            );
            
            return { id: product.id, ...result };
        } catch (error) {
            console.error('Error in create product:', error);
            throw error;
        }
    }

    // Update product
    static async update(id, product) {
        try {
            // Convert specs object to JSON string if it exists
            if (product.specs && typeof product.specs === 'object') {
                product.specs = JSON.stringify(product.specs);
            }

            // Ensure image URL is properly formatted
            let imageUrl = product.image;
            if (imageUrl && imageUrl.startsWith('/uploads/')) {
                // Already correctly formatted
                imageUrl = product.image;
            } else if (imageUrl && !imageUrl.startsWith('http')) {
                // Only add the prefix if it's not already an absolute URL
                imageUrl = `/uploads/${imageUrl.replace(/^\/+/, '')}`;
            }

            // Get current product to check if category changed
            const [currentProducts] = await pool.query('SELECT category FROM products WHERE id = ?', [id]);
            const oldCategory = currentProducts.length ? currentProducts[0].category : null;
            
            const [result] = await pool.query(
                `UPDATE products SET 
                name = ?, 
                category = ?, 
                description = ?, 
                price = ?, 
                image = ?, 
                featured = ?, 
                inStock = ?, 
                new = ?, 
                rating = ?, 
                reviewCount = ?, 
                specs = ?
                WHERE id = ?`,
                [
                    product.name,
                    product.category,
                    product.description,
                    product.price,
                    imageUrl,
                    product.featured ? 1 : 0,
                    product.inStock ? 1 : 0,
                    product.new ? 1 : 0,
                    product.rating || 0,
                    product.reviewCount || 0,
                    product.specs || null,
                    id
                ]
            );

            // Update category counts if category changed
            if (oldCategory && oldCategory !== product.category) {
                await pool.query('UPDATE categories SET count = count - 1 WHERE id = ?', [oldCategory]);
                await pool.query('UPDATE categories SET count = count + 1 WHERE id = ?', [product.category]);
            }
            
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in update product (${id}):`, error);
            throw error;
        }
    }

    // Delete product
    static async delete(id) {
        try {
            // Get product category before deleting
            const [rows] = await pool.query('SELECT category FROM products WHERE id = ?', [id]);
            const category = rows.length ? rows[0].category : null;
            
            const [result] = await pool.query('DELETE FROM products WHERE id = ?', [id]);
            
            // Update category count if product was found and deleted
            if (category && result.affectedRows > 0) {
                await pool.query('UPDATE categories SET count = count - 1 WHERE id = ?', [category]);
            }
            
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in delete product (${id}):`, error);
            throw error;
        }
    }
}

module.exports = Product; 