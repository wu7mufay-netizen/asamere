const { pool } = require('./database');
const crypto = require('crypto');

class User {
    // Get all users
    static async getAll() {
        try {
            const [rows] = await pool.query('SELECT id, username, email, role, created_at FROM users');
            return rows;
        } catch (error) {
            console.error('Error in getAll users:', error);
            throw error;
        }
    }

    // Get user by ID
    static async getById(id) {
        try {
            const [rows] = await pool.query(
                'SELECT id, username, email, role, created_at FROM users WHERE id = ?', 
                [id]
            );
            return rows.length ? rows[0] : null;
        } catch (error) {
            console.error(`Error in getById user (${id}):`, error);
            throw error;
        }
    }

    // Get user by username
    static async getByUsername(username) {
        try {
            const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
            return rows.length ? rows[0] : null;
        } catch (error) {
            console.error(`Error in getByUsername user (${username}):`, error);
            throw error;
        }
    }

    // Get user by email
    static async getByEmail(email) {
        try {
            const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
            return rows.length ? rows[0] : null;
        } catch (error) {
            console.error(`Error in getByEmail user (${email}):`, error);
            throw error;
        }
    }

    // Create user
    static async create(userData) {
        try {
            // Hash password
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = crypto.pbkdf2Sync(userData.password, salt, 1000, 64, 'sha512').toString('hex');
            
            const [result] = await pool.query(
                `INSERT INTO users (username, email, password, salt, role) VALUES (?, ?, ?, ?, ?)`,
                [
                    userData.username,
                    userData.email,
                    hash,
                    salt,
                    userData.role || 'customer'
                ]
            );
            
            return { id: result.insertId, username: userData.username };
        } catch (error) {
            console.error('Error in create user:', error);
            throw error;
        }
    }

    // Update user
    static async update(id, userData) {
        try {
            let query = 'UPDATE users SET username = ?, email = ?, role = ?';
            const params = [userData.username, userData.email, userData.role];
            
            // If password is provided, hash it
            if (userData.password) {
                const salt = crypto.randomBytes(16).toString('hex');
                const hash = crypto.pbkdf2Sync(userData.password, salt, 1000, 64, 'sha512').toString('hex');
                query += ', password = ?, salt = ?';
                params.push(hash, salt);
            }
            
            query += ' WHERE id = ?';
            params.push(id);
            
            const [result] = await pool.query(query, params);
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in update user (${id}):`, error);
            throw error;
        }
    }

    // Delete user
    static async delete(id) {
        try {
            const [result] = await pool.query('DELETE FROM users WHERE id = ?', [id]);
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in delete user (${id}):`, error);
            throw error;
        }
    }

    // Verify password
    static async verifyPassword(username, password) {
        try {
            const user = await this.getByUsername(username);
            
            if (!user) {
                return null;
            }
            
            const hash = crypto.pbkdf2Sync(password, user.salt, 1000, 64, 'sha512').toString('hex');
            
            if (hash === user.password) {
                return {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role
                };
            }
            
            return null;
        } catch (error) {
            console.error(`Error in verifyPassword for user (${username}):`, error);
            throw error;
        }
    }
}

module.exports = User; 