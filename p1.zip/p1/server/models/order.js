const { pool } = require('./database');

class Order {
    // Get all orders
    static async getAll() {
        try {
            const [rows] = await pool.query(`
                SELECT o.*, 
                    COUNT(oi.id) as itemCount, 
                    SUM(oi.quantity) as totalQuantity 
                FROM orders o
                LEFT JOIN order_items oi ON o.id = oi.order_id
                GROUP BY o.id
                ORDER BY o.created_at DESC
            `);
            return rows;
        } catch (error) {
            console.error('Error in getAll orders:', error);
            throw error;
        }
    }

    // Get order by ID with items
    static async getById(id) {
        try {
            // Get order
            const [orders] = await pool.query('SELECT * FROM orders WHERE id = ?', [id]);
            if (orders.length === 0) {
                return null;
            }
            
            const order = orders[0];
            
            // Get order items
            const [items] = await pool.query(`
                SELECT oi.*, p.name, p.image
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = ?
            `, [id]);
            
            order.items = items;
            return order;
        } catch (error) {
            console.error(`Error in getById order (${id}):`, error);
            throw error;
        }
    }

    // Create order
    static async create(orderData) {
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            // Insert order
            const [orderResult] = await connection.query(
                `INSERT INTO orders 
                (customer_name, customer_email, customer_address, total_amount, payment_method, status) 
                VALUES (?, ?, ?, ?, ?, ?)`,
                [
                    orderData.customer_name,
                    orderData.customer_email,
                    orderData.customer_address,
                    orderData.total_amount,
                    orderData.payment_method,
                    orderData.status || 'pending'
                ]
            );
            
            const orderId = orderResult.insertId;
            
            // Insert order items
            if (orderData.items && Array.isArray(orderData.items)) {
                for (const item of orderData.items) {
                    await connection.query(
                        `INSERT INTO order_items 
                        (order_id, product_id, quantity, price, subtotal) 
                        VALUES (?, ?, ?, ?, ?)`,
                        [
                            orderId,
                            item.product_id,
                            item.quantity,
                            item.price,
                            item.quantity * item.price
                        ]
                    );
                    
                    // Update product stock (if we were tracking inventory)
                    // await connection.query(
                    //     'UPDATE products SET stock = stock - ? WHERE id = ?',
                    //     [item.quantity, item.product_id]
                    // );
                }
            }
            
            await connection.commit();
            return { id: orderId };
        } catch (error) {
            await connection.rollback();
            console.error('Error in create order:', error);
            throw error;
        } finally {
            connection.release();
        }
    }

    // Update order status
    static async updateStatus(id, status) {
        try {
            const [result] = await pool.query(
                'UPDATE orders SET status = ? WHERE id = ?',
                [status, id]
            );
            return { affectedRows: result.affectedRows };
        } catch (error) {
            console.error(`Error in updateStatus order (${id}):`, error);
            throw error;
        }
    }

    // Delete order
    static async delete(id) {
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            // Delete order items
            await connection.query('DELETE FROM order_items WHERE order_id = ?', [id]);
            
            // Delete order
            const [result] = await connection.query('DELETE FROM orders WHERE id = ?', [id]);
            
            await connection.commit();
            return { affectedRows: result.affectedRows };
        } catch (error) {
            await connection.rollback();
            console.error(`Error in delete order (${id}):`, error);
            throw error;
        } finally {
            connection.release();
        }
    }
}

module.exports = Order; 