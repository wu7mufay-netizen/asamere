const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const { testConnection } = require('./models/database');
const routes = require('./routes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files
app.use(express.static(path.join(__dirname, '../')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/server/public/admin', express.static(path.join(__dirname, 'public/admin')));

// Add a specific route for admin.html at the root
app.get('/admin.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../admin.html'));
});

// API routes
app.use('/api', routes);

// Error handling middleware
app.use(errorHandler);

// Serve static files for all routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../index.html'));
});

// Start the server
app.listen(PORT, async () => {
    console.log(`Server running on port ${PORT}`);
    try {
        const connected = await testConnection();
        if (!connected) {
            console.warn('WARNING: Database connection failed. The website will run with limited functionality.');
            console.warn('To fix this issue, please:');
            console.warn('1. Install MySQL if not already installed');
            console.warn('2. Ensure MySQL service is running');
            console.warn('3. Verify connection settings in server/models/database.js');
        }
    } catch (error) {
        console.error('Error testing database connection:', error);
        console.warn('WARNING: Database connection failed. The website will run with limited functionality.');
    }
});

module.exports = app; 