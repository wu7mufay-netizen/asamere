# MySQL Integration for Asamere Furniture

This document provides instructions on how to set up and use the MySQL integration for the Asamere Furniture website.

## Prerequisites

- Node.js (v14 or higher)
- MySQL Server (v5.7 or higher)
- npm (Node Package Manager)

## Setup Instructions

### 1. MySQL Server Setup

Make sure you have MySQL Server installed and running on your machine. If not, download and install it from the [official MySQL website](https://dev.mysql.com/downloads/).

### 2. Install Node.js Dependencies

Navigate to the server directory and install the required Node.js dependencies:

```bash
cd server
npm install
```

### 3. Configure Database Connection

Open the `server/server.js` file and update the MySQL connection settings to match your environment:

```javascript
// Database connection pool
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'your-mysql-password', // Change this to your MySQL password
    database: 'asamere_furniture',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});
```

Also update the same settings in the `server/db-setup.js` file.

### 4. Initialize the Database

Run the database setup script to create the necessary tables and load sample data:

```bash
cd server
npm run setup
```

This script will:
1. Create the `asamere_furniture` database if it doesn't exist
2. Create the `products` and `categories` tables
3. Insert sample categories and products

### 5. Start the Server

Start the Node.js server:

```bash
cd server
npm start
```

For development with automatic restart on file changes:

```bash
cd server
npm run dev
```

The server will start on port 5000 by default. You can access the API at `http://localhost:5000/api`.

## API Endpoints

### Products

- `GET /api/products` - Get all products
- `GET /api/products/:id` - Get a specific product by ID
- `GET /api/products/category/:category` - Get products by category
- `GET /api/products/featured/items` - Get featured products
- `GET /api/products/new/arrivals` - Get new arrivals
- `GET /api/products/search/items?term=search_term` - Search products
- `POST /api/products` - Create a new product
- `PUT /api/products/:id` - Update a product
- `DELETE /api/products/:id` - Delete a product

### Categories

- `GET /api/categories` - Get all categories
- `GET /api/categories/:id` - Get a specific category by ID

### Database Setup

- `GET /api/setup` - Set up database tables (run once during initial setup)

## Client-Side Integration

The website has been updated to use the MySQL database via the API. Key files that have been modified:

1. `static/js/api.js` - API client for communicating with the MySQL server
2. `static/js/products.js` - Updated to use the API for product display
3. `static/js/admin.js` - Updated to use the API for product management

## Troubleshooting

### Database Connection Issues

If you encounter database connection issues:

1. Verify that MySQL Server is running
2. Check the connection settings in `server.js`
3. Ensure the `asamere_furniture` database exists
4. Check console logs for specific error messages

### API Errors

If you see API error messages in the browser console:

1. Make sure the Node.js server is running
2. Check the server console for error logs
3. Verify that your API endpoint is correct
4. Check network requests in browser developer tools

## Migrating from LocalStorage

This implementation replaces the previous LocalStorage-based data storage. When you run the setup script, sample data will be loaded into the MySQL database. Any existing data in LocalStorage will no longer be used by the application.

## Additional Notes

- The MySQL integration uses connection pooling for better performance
- API responses are JSON-formatted
- Error handling is implemented for all API endpoints
- The server supports CORS for cross-origin requests 