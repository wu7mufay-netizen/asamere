#!/bin/bash

echo "==================================="
echo "Asamere Furniture MySQL Setup Script"
echo "==================================="
echo

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js is not installed or not in your PATH."
    echo "Please install Node.js from https://nodejs.org/"
    exit 1
fi

echo "Node.js is installed."
echo

# Create server directory if it doesn't exist
mkdir -p server

echo "Installing server dependencies..."
cd server
npm install

echo
echo "Database setup script is ready to run."
echo
echo "Before continuing, make sure:"
echo "1. MySQL Server is installed and running"
echo "2. You have updated the database connection settings in:"
echo "   - server/server.js"
echo "   - server/db-setup.js"
echo
read -p "Press Enter to continue with database setup..."

echo "Running database setup script..."
npm run setup

if [ $? -ne 0 ]; then
    echo
    echo "ERROR: Database setup failed."
    echo "Please check your MySQL connection settings and try again."
    exit 1
fi

echo
echo "Database setup completed successfully!"
echo
echo "Starting the server..."
echo "(Press Ctrl+C to stop the server when finished)"
echo
npm start

echo
echo "Script completed." 